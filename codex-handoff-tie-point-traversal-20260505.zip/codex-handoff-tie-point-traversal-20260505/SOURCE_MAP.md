# 源码证据清单

## 核心算法

- `source/src/shared/matrix.ts`
  - 本地矩阵点号遍历、坐标映射、2x2 分组、组导航。
  - 重点函数：`buildTraversalData`、`getPointCoordinate`、`getPointIdAtCoordinate`、`getGroupIndex`、`getGroupPointIdsForPoint`、`getGroupNavigationPointId`。

- `source/src/shared/acceptance-plan.ts`
  - ROS 规划 JSON 解析。
  - 重点函数：`parseAcceptancePlanJson`、`normalizePlanPoint`。

- `source/src/shared/types.ts`
  - `AcceptancePlanPayload`、`AcceptancePlanArea`、`AutoGroupSavePayload` 等跨端数据结构。

## 前端状态与遍历控制

- `source/src/client/store.ts`
  - 两种遍历模式的切换点。
  - 重点看 `acceptancePlan`、`currentGroupIndex`、`currentGroupPointIds`、`goToGroup`、`moveGroup`、`saveCurrentGroupAndMoveNext`、`saveGroupFromRos`、`resolveExternalGroupIndex`。

- `source/src/client/acceptance-plan.ts`
  - 订阅 ROS `/acceptance/plan`。

- `source/src/client/area-progress.ts`
  - 订阅和归一化 `/cabin/area_progress`。

- `source/docs/components/AcceptanceApp.vue`
  - 把 ROS 规划、区域进度、当前组 UI、自动保存串起来。

## 服务端与 ROS 桥

- `source/src/server/http.ts`
  - `/api/acceptance-plan` 从本地或 SSH 读取规划 JSON。
  - `/api/group-save/auto` 接收 ROS 自动保存。

- `source/src/server/repository.ts`
  - `saveManualGroupRecord`、`saveAutoGroupRecord`、`buildGroupSnapshot`、Excel 导出按组输出。

- `source/src/server/index.ts`
  - 默认规划路径、SSH target、服务监听入口。

- `source/scripts/ros/acceptance_plan_publisher.py`
  - ROS 侧读取 `pseudo_slam_bind_path.json` 并 latched 发布 `/acceptance/plan`。

## 测试

- `source/tests/shared/matrix.test.ts`
  - 本地蛇形遍历、2x2 分组、边缘重叠、旋转显示不改变底层遍历。

- `source/tests/shared/acceptance-plan.test.ts`
  - ROS 稀疏规划解析：area 顺序、pointId、row/column、worldCoord。

- `source/tests/client/store.test.ts`
  - ROS 规划接管分组、非连续 area 跳转、ROS 完成区域显式保存。

- `source/tests/client/area-progress.test.ts`
  - 区域进度字段归一化和 all_done 处理。

- `source/tests/server/http.test.ts`
  - API 层规划读取、自动保存与导出相关回归。

