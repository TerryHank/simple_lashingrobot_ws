# 绑扎点遍历方法交接包

本包面向下一个 Codex。目标是快速读懂本工程“绑扎点如何遍历、如何分组、如何跟 ROS 区域进度同步”的实现，不需要先跑完整前端。

## 先读顺序

1. `HANDOFF.md`
2. `SOURCE_MAP.md`
3. `source/src/shared/matrix.ts`
4. `source/src/shared/acceptance-plan.ts`
5. `source/src/client/store.ts`
6. `source/docs/components/AcceptanceApp.vue`
7. `source/tests/shared/matrix.test.ts`
8. `source/tests/client/store.test.ts`

## 一句话结论

工程存在两套绑扎点遍历来源：

- 本地矩阵模式：`src/shared/matrix.ts` 用“两列为一带、两行为一组、按 x 带蛇形上下遍历”的算法生成点号、坐标、2x2 物理组和组导航点。
- ROS 规划模式：收到 `/acceptance/plan` 或读取 `pseudo_slam_bind_path.json` 后，`src/shared/acceptance-plan.ts` 用 ROS 的 `area_index` 和 `global_idx/global_row/global_col` 接管分组与遍历，前端 store 不再按本地矩阵重新推导组。

## 验证入口

在原工程根目录运行：

```powershell
npm test -- --runInBand
npm run build:server
```

如果只想验证遍历逻辑，可优先看这些测试：

```powershell
npx vitest run tests/shared/matrix.test.ts tests/shared/acceptance-plan.test.ts tests/client/store.test.ts
```

