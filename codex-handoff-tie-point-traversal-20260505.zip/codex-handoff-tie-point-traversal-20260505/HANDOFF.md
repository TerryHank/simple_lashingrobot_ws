# 本工程如何遍历绑扎点

## 范围

本交接只解释“绑扎点遍历/分组/区域同步”方法，不解释整站 UI 样式。关键实现分布在：

- 本地矩阵遍历：`src/shared/matrix.ts`
- ROS 规划解析：`src/shared/acceptance-plan.ts`
- 前端状态与跳组：`src/client/store.ts`
- ROS 实时接入与自动保存：`docs/components/AcceptanceApp.vue`、`src/client/acceptance-plan.ts`、`src/client/area-progress.ts`
- 服务端规划文件读取与保存记录：`src/server/http.ts`、`src/server/repository.ts`

## 模式 1：本地矩阵遍历

当没有 ROS 规划时，点位来自工程默认矩阵设置，默认是 `1200` 个点、`40` 列、`30` 行。核心函数是 `buildTraversalData(pointCount, columnCount)`。

算法要点：

1. 先计算行数：`rowCount = ceil(pointCount / columnCount)`。
2. 横向每两列为一个 `xBand`：`xBandCount = ceil(columnCount / 2)`。
3. 纵向每两行为一个 `yBand`：`yBandCount = ceil(rowCount / 2)`。
4. `xBand` 偶数时，`yBand` 从小到大走；`xBand` 奇数时，`yBand` 从大到小走。
5. 每个 2x2 局部组内部也跟随方向切换：
   - 偶数 `xBand`：`(0,0) -> (1,0) -> (0,1) -> (1,1)`
   - 奇数 `xBand`：`(0,1) -> (1,1) -> (0,0) -> (1,0)`
6. 每生成一个有效坐标，就分配下一个 `pointId`，并建立：
   - `coordinatesById[pointId - 1] = { x, y }`
   - `pointIdByCoordinate["x:y"] = pointId`

这个顺序就是本地模式下点号的遍历顺序。它不是普通逐行扫描，而是“两列带内 2x2，x 方向换带，y 方向蛇形”的遍历。

## 本地模式的分组

同一个 `buildTraversalData` 会再构建 `groups`：

- 每个组对应一个 2x2 物理区域。
- `getGroupIndex(pointId, pointCount, columnCount)` 先把点号转回坐标，再用 `floor(x / 2)`、`floor(y / 2)` 找到所属带。
- `getGroupPointIdsForPoint(pointId, ...)` 返回当前点所在组的点号列表。
- `getGroupPointIds(groupIndex, ...)` 按遍历顺序返回某个组的点号列表。
- `getGroupNavigationPointId(groupIndex, ...)` 返回跳到某组时应该选中的点。

边缘处理：

- 行数或列数不是 2 的倍数时，`getBandStart()` 会把最外侧不足 2 行/列的区域向内重叠，尽量仍形成 2x2 组。
- 测试里 `81` 点、`9` 列的用例覆盖了这一点：顶部边缘组会向内重叠一行。

## 模式 2：ROS 规划遍历

一旦收到 ROS 规划，本地矩阵分组会被覆盖。

数据来源有两条：

- 浏览器实时订阅 `/acceptance/plan`，消息类型是 `std_msgs/String`。
- 服务端 `/api/acceptance-plan` 读取 `ACCEPTANCE_PLAN_PATH`，默认路径是 `/home/hyq-/simple_lashingrobot_ws/src/chassis_ctrl/data/pseudo_slam_bind_path.json`；如果本地不存在，会通过 `ACCEPTANCE_PLAN_SSH_TARGET` 默认 `hyq-@192.168.6.99` 去 `ssh cat`。

ROS 规划解析函数是 `parseAcceptancePlanJson(payload)`。它读取：

- `areas[].area_index` -> 前端组号/区域号
- `areas[].groups[].points[].global_idx` -> `pointId`
- `global_col` -> `x`
- `global_row` -> `y`
- `local_idx` -> 区域内顺序
- `x/y/z` -> 世界坐标
- `angle/checkerboard_parity/is_checkerboard_member` -> 点位附加信息

解析结果：

- `areas` 按 `areaIndex` 排序。
- 每个 `area.pointIds` 保留 ROS JSON 中出现顺序，并去重。
- `points` 按 `pointId` 排序，方便绘制全局点阵。
- `rowCount = max(global_row) + 1`，`columnCount = max(global_col) + 1`。
- `pointCount = 实际解析出的唯一点数量`，`maxPointId = 最大 global_idx`。二者可能不同，因为 ROS 规划可以是稀疏点号。

## 前端 store 如何在两种模式间切换

`createAcceptanceStore()` 里有一个 `acceptancePlan` 状态。

没有规划时：

- `currentGroupIndex = getGroupIndex(selectedPointId, settings.pointCount, settings.columnCount)`
- `currentGroupPointIds = getGroupPointIdsForPoint(selectedPointId, ...)`
- `goToGroup(groupIndex)` 用 `getGroupNavigationPointId()` 找目标点。
- `moveGroup(offset)` 通过当前组号加减来走。
- `saveCurrentGroupAndMoveNext()` 保存后进入 `currentGroupIndex + 1`。

有 ROS 规划时：

- `matrixMeta` 使用规划中的 `pointCount/rowCount/columnCount`。
- `currentGroupIndex` 使用当前点所在 `area.areaIndex`。
- `currentGroupPointIds` 直接使用当前 area 的 `pointIds`。
- `goToGroup(groupIndex)` 把 `groupIndex` 当 ROS 的 `area_index`，选中该 area 第一个点。
- `moveGroup(offset)` 按 `planAreas` 的数组顺序移动，不按数值连续假设移动。
- `saveCurrentGroupAndMoveNext()` 保存后跳到下一个可用 area，而不是 `areaIndex + 1`。
- `getGroupIndexForPoint(pointId)` 返回该点所属 `areaIndex`。
- `getPointIdsForGroup(groupIndex)` 返回对应 `area.pointIds`。

注意：ROS 规划模式里 `area_index` 可以不连续。例如测试里有 area `2` 和 `4`，前端会从 `2` 的 ordinal 下一步跳到 `4`。

## ROS 区域进度如何驱动遍历

`src/client/area-progress.ts` 订阅 `/cabin/area_progress`，消息类型是 `chassis_ctrl/AreaProgress`。核心字段：

- `current_area_index`：机器人当前区域。
- `total_area_count`：区域总数。
- `just_finished_area_index`：刚完成的区域。
- `ready_for_next_area`：完成并准备进入下一区。
- `all_done`：全部完成。

`AcceptanceApp.vue` 有两类 watcher：

1. 当前区域同步 watcher
   - 把 `areaProgress.state.currentAreaIndex` 通过 `store.resolveExternalGroupIndex()` 映射成前端组。
   - 如果当前前端组和 ROS 目标组不同，调用 `store.goToGroup(targetGroupIndex)`。
   - 当 ROS 正在控制区域时，用户点击其它组会被限制，只能点当前 ROS 区域内的点。

2. 自动保存 watcher
   - 当 `ready_for_next_area=true` 且 `just_finished_area_index` 有效时触发。
   - 用 `lastAutoSavedGroupIndex` 防止同一区域重复保存。
   - 调用 `store.saveGroupFromRos({ groupIndex: justFinishedAreaIndex, ... })`。
   - `saveGroupFromRos()` 会用 `getPointIdsForGroup(groupIndex)[0]` 作为保存记录的 `selectedPointId`，所以即使当前 UI 已跳到别的区域，也能把刚完成的区域按显式 `groupIndex` 保存。

## 服务端保存时的关键差异

手动保存：

- 前端无 ROS 规划时调用 `/api/group-save/manual`。
- 服务端 `saveManualGroupRecord()` 用 `getGroupPointIdsForPoint(selectedPointId, ...)` 校验备注点必须在当前本地矩阵组里。
- `buildGroupSnapshot()` 使用本地矩阵算法保存该组点位快照。

ROS 自动保存：

- 前端调用 `/api/group-save/auto`，会传 `groupIndex`、`selectedPointId`、检测点、图片等。
- 服务端 `saveAutoGroupRecord()` 会写入 `group_save_records`。
- `groupIndex` 采用前端显式传入值，避免用当前选择点重新推导错组。

## 最容易误改的点

- 不要把本地矩阵遍历改成普通行优先扫描。本项目测试明确要求“两列带 + y 方向蛇形”。
- 不要假设 ROS `area_index` 连续。前端移动用 `planAreas` 的 ordinal，跳转用真实 `areaIndex`。
- 不要用 `pointCount` 当最大点号。ROS 稀疏规划里 `pointCount` 是唯一点数量，`maxPointId` 才是最大 `global_idx`。
- 不要把自动保存绑定到当前 UI 选中组。它必须按 `just_finished_area_index` 保存刚完成的区域。
- 只旋转显示，不改变底层遍历。`getRotatedDisplayCoordinate()` 只影响渲染坐标。

