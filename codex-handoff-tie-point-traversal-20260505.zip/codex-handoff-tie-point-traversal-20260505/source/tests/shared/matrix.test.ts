import { describe, expect, it } from 'vitest'
import {
  formatAxisValue,
  getLogicalCoordinateFromDisplay,
  getGroupCount,
  getGroupIndex,
  getGroupNavigationPointId,
  getGroupPointIds,
  getGroupPointIdsForPoint,
  getMatrixDimensions,
  getPointCountFromGrid,
  getPointCoordinate,
  getPointIdAtCoordinate,
  getRotatedDisplayCoordinate,
  getRotatedMatrixDimensions
} from '../../src/shared/matrix.js'

describe('matrix mapping', () => {
  it('derives near-square dimensions from point count', () => {
    expect(getMatrixDimensions(10)).toEqual({ columnCount: 4, rowCount: 3 })
    expect(getMatrixDimensions(1200)).toEqual({ columnCount: 35, rowCount: 35 })
  })

  it('derives point count from explicit row and column values', () => {
    expect(getPointCountFromGrid(30, 40)).toBe(1200)
    expect(getPointCountFromGrid(9, 9)).toBe(81)
  })

  it('maps coordinates with a y-direction snake across two-column bands', () => {
    expect(getPointCoordinate(1, 10, 4)).toEqual({ x: 0, y: 0 })
    expect(getPointCoordinate(3, 10, 4)).toEqual({ x: 0, y: 1 })
    expect(getPointCoordinate(4, 10, 4)).toEqual({ x: 1, y: 1 })
    expect(getPointCoordinate(5, 10, 4)).toEqual({ x: 0, y: 2 })
    expect(getPointCoordinate(7, 10, 4)).toEqual({ x: 2, y: 2 })
    expect(getPointCoordinate(10, 10, 4)).toEqual({ x: 3, y: 1 })
  })

  it('maps coordinates back to point ids and ignores empty cells', () => {
    expect(getPointIdAtCoordinate(0, 1, 10, 4)).toBe(3)
    expect(getPointIdAtCoordinate(1, 1, 10, 4)).toBe(4)
    expect(getPointIdAtCoordinate(2, 2, 10, 4)).toBe(7)
    expect(getPointIdAtCoordinate(3, 1, 10, 4)).toBe(10)
    expect(getPointIdAtCoordinate(2, 0, 10, 4)).toBeNull()
  })

  it('returns a 2 x 2 physical group based on matrix coordinates', () => {
    expect(getGroupPointIdsForPoint(1, 10, 4)).toEqual([1, 2, 3, 4])
    expect(getGroupPointIdsForPoint(6, 10, 4)).toEqual([3, 4, 5, 6])
    expect(getGroupPointIdsForPoint(7, 10, 4)).toEqual([7, 8, 9, 10])
    expect(getGroupPointIdsForPoint(9, 10, 4)).toEqual([9, 10])
  })

  it('maps point ids to physical matrix group indexes while preserving prior edge bands', () => {
    expect(getGroupIndex(1, 10, 4)).toBe(1)
    expect(getGroupIndex(6, 10, 4)).toBe(2)
    expect(getGroupIndex(7, 10, 4)).toBe(3)
    expect(getGroupIndex(9, 10, 4)).toBe(4)
  })

  it('lists groups by y-direction snake bands and lets edge bands overlap inward', () => {
    expect(getGroupCount(10, 4)).toBe(4)
    expect(getGroupPointIds(1, 10, 4)).toEqual([1, 2, 3, 4])
    expect(getGroupPointIds(2, 10, 4)).toEqual([3, 4, 5, 6])
    expect(getGroupPointIds(3, 10, 4)).toEqual([7, 8, 9, 10])
    expect(getGroupPointIds(4, 10, 4)).toEqual([9, 10])
  })

  it('overlaps inward only for the outermost edge band', () => {
    const topEdgePointId = getPointIdAtCoordinate(0, 8, 81, 9)
    const penultimateRowPointId = getPointIdAtCoordinate(0, 7, 81, 9)
    expect(topEdgePointId).not.toBeNull()
    expect(penultimateRowPointId).not.toBeNull()
    expect(getGroupPointIdsForPoint(topEdgePointId!, 81, 9)).toEqual([
      getPointIdAtCoordinate(0, 7, 81, 9),
      getPointIdAtCoordinate(1, 7, 81, 9),
      getPointIdAtCoordinate(0, 8, 81, 9),
      getPointIdAtCoordinate(1, 8, 81, 9)
    ])
    expect(getGroupPointIdsForPoint(penultimateRowPointId!, 81, 9)).toEqual([
      getPointIdAtCoordinate(0, 6, 81, 9),
      getPointIdAtCoordinate(1, 6, 81, 9),
      getPointIdAtCoordinate(0, 7, 81, 9),
      getPointIdAtCoordinate(1, 7, 81, 9)
    ])
  })

  it('returns a navigation point that belongs to the requested overlapping edge group', () => {
    expect(getGroupNavigationPointId(5, 81, 9)).toBe(17)
    expect(getGroupIndex(getGroupNavigationPointId(5, 81, 9), 81, 9)).toBe(5)
    expect(getGroupNavigationPointId(6, 81, 9)).toBe(19)
    expect(getGroupIndex(getGroupNavigationPointId(6, 81, 9), 81, 9)).toBe(6)
  })

  it('formats axis values as one-based two-digit strings', () => {
    expect(formatAxisValue(0)).toBe('01')
    expect(formatAxisValue(7)).toBe('08')
    expect(formatAxisValue(12)).toBe('13')
  })

  it('rotates display coordinates without changing the underlying snake traversal', () => {
    expect(getRotatedMatrixDimensions(3, 4, 0)).toEqual({ rowCount: 3, columnCount: 4 })
    expect(getRotatedMatrixDimensions(3, 4, 90)).toEqual({ rowCount: 4, columnCount: 3 })
    expect(getRotatedDisplayCoordinate({ x: 0, y: 0 }, 3, 4, 0)).toEqual({ x: 0, y: 2 })
    expect(getRotatedDisplayCoordinate({ x: 0, y: 0 }, 3, 4, 90)).toEqual({ x: 2, y: 3 })
    expect(getRotatedDisplayCoordinate({ x: 0, y: 0 }, 3, 4, 180)).toEqual({ x: 3, y: 0 })
    expect(getRotatedDisplayCoordinate({ x: 0, y: 0 }, 3, 4, 270)).toEqual({ x: 0, y: 0 })
    expect(getLogicalCoordinateFromDisplay(2, 3, 3, 4, 90)).toEqual({ x: 0, y: 0 })
    expect(getLogicalCoordinateFromDisplay(3, 0, 3, 4, 180)).toEqual({ x: 0, y: 0 })
    expect(getLogicalCoordinateFromDisplay(0, 0, 3, 4, 270)).toEqual({ x: 0, y: 0 })
  })

  it('rejects invalid matrix dimensions and point coordinates', () => {
    expect(() => getMatrixDimensions(0)).toThrow(RangeError)
    expect(() => getMatrixDimensions(-1)).toThrow(RangeError)
    expect(() => getPointCountFromGrid(0, 4)).toThrow(RangeError)
    expect(() => getPointCountFromGrid(3, 0)).toThrow(RangeError)
    expect(() => getPointCoordinate(0, 10, 4)).toThrow(RangeError)
    expect(() => getPointCoordinate(1, 10, 0)).toThrow(RangeError)
    expect(() => getPointCoordinate(-1, 10, 4)).toThrow(RangeError)
    expect(() => getPointCoordinate(11, 10, 4)).toThrow(RangeError)
  })

  it('returns null for invalid coordinate lookups', () => {
    expect(getPointIdAtCoordinate(-1, 0, 10, 4)).toBeNull()
    expect(getPointIdAtCoordinate(4, 0, 10, 4)).toBeNull()
    expect(getPointIdAtCoordinate(0, -1, 10, 4)).toBeNull()
    expect(getPointIdAtCoordinate(2, 0, 10, 4)).toBeNull()
    expect(() => getPointIdAtCoordinate(0, 0, 0, 4)).toThrow(RangeError)
    expect(() => getPointIdAtCoordinate(0, 0, 10, 0)).toThrow(RangeError)
  })

  it('rejects invalid group helper input', () => {
    expect(() => getGroupIndex(0, 10, 4)).toThrow(RangeError)
    expect(() => getGroupIndex(1, 0, 4)).toThrow(RangeError)
    expect(() => getGroupIndex(1, 10, 0)).toThrow(RangeError)
    expect(() => getGroupPointIdsForPoint(0, 10, 4)).toThrow(RangeError)
    expect(() => getGroupPointIdsForPoint(1, 0, 4)).toThrow(RangeError)
    expect(() => getGroupPointIdsForPoint(11, 10, 4)).toThrow(RangeError)
    expect(() => getGroupPointIdsForPoint(1, 10, 0)).toThrow(RangeError)
    expect(() => getGroupPointIds(0, 10, 4)).toThrow(RangeError)
    expect(() => getGroupPointIds(5, 10, 4)).toThrow(RangeError)
    expect(() => getGroupNavigationPointId(5, 10, 4)).toThrow(RangeError)
  })
})
