import { describe, expect, it } from 'vitest'
import { parseAcceptancePlanJson } from '../../src/shared/acceptance-plan.js'

describe('acceptance plan parser', () => {
  it('parses sparse ROS area plans into points, areas, and display dimensions', () => {
    const parsed = parseAcceptancePlanJson(
      JSON.stringify({
        areas: [
          {
            area_index: 2,
            groups: [
              {
                points: [
                  { global_idx: 3, global_row: 0, global_col: 2, local_idx: 1, x: 1, y: 2, z: 3, angle: 12, checkerboard_parity: 1, is_checkerboard_member: true },
                  { global_idx: 1, global_row: 0, global_col: 3, local_idx: 2, x: 4, y: 5, z: 6, angle: 24, checkerboard_parity: 0, is_checkerboard_member: false },
                  { global_idx: 5, global_row: 1, global_col: 2, local_idx: 3, x: 7, y: 8, z: 9, angle: 36, checkerboard_parity: 1, is_checkerboard_member: true },
                  { global_idx: 2, global_row: 1, global_col: 3, local_idx: 4, x: 10, y: 11, z: 12, angle: 48, checkerboard_parity: 0, is_checkerboard_member: false }
                ]
              }
            ]
          },
          {
            area_index: 4,
            groups: [
              {
                points: [
                  { global_idx: 15, global_row: 0, global_col: 4, local_idx: 1, x: 1, y: 2, z: 3, angle: 0, checkerboard_parity: 1, is_checkerboard_member: true },
                  { global_idx: 13, global_row: 0, global_col: 5, local_idx: 2, x: 1, y: 2, z: 3, angle: 0, checkerboard_parity: 1, is_checkerboard_member: true },
                  { global_idx: 16, global_row: 1, global_col: 4, local_idx: 3, x: 1, y: 2, z: 3, angle: 0, checkerboard_parity: 1, is_checkerboard_member: true },
                  { global_idx: 14, global_row: 1, global_col: 5, local_idx: 4, x: 1, y: 2, z: 3, angle: 0, checkerboard_parity: 1, is_checkerboard_member: true }
                ]
              }
            ]
          }
        ]
      }),
      '2026-04-17T08:00:00.000Z'
    )

    expect(parsed).not.toBeNull()
    expect(parsed).toMatchObject({
      pointCount: 8,
      maxPointId: 16,
      rowCount: 2,
      columnCount: 6,
      receivedAt: '2026-04-17T08:00:00.000Z',
      areas: [
        { areaIndex: 2, pointIds: [3, 1, 5, 2] },
        { areaIndex: 4, pointIds: [15, 13, 16, 14] }
      ]
    })
    expect(parsed?.points.find((point) => point.pointId === 5)).toEqual(
      expect.objectContaining({
        areaIndex: 2,
        localIndex: 3,
        x: 2,
        y: 1,
        worldCoord: [7, 8, 9],
        angle: 36
      })
    )
  })

  it('returns null for invalid or empty payloads', () => {
    expect(parseAcceptancePlanJson('')).toBeNull()
    expect(parseAcceptancePlanJson('not-json')).toBeNull()
    expect(parseAcceptancePlanJson(JSON.stringify({ areas: [] }))).toBeNull()
  })
})
