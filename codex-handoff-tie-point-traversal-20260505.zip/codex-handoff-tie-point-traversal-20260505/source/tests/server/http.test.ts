import { existsSync, mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import ExcelJS from 'exceljs'
import * as XLSX from 'xlsx'
import { createApp } from '../../src/server/http.js'

describe('http api', () => {
  const closers: Array<() => void> = []
  const tempDirs: string[] = []

  afterEach(() => {
    while (closers.length > 0) {
      const close = closers.pop()
      close?.()
    }

    while (tempDirs.length > 0) {
      const dir = tempDirs.pop()
      if (dir) {
        rmSync(dir, { recursive: true, force: true })
      }
    }
  })

  it('creates scenes and exposes sparse records in form payload', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    const createScene = await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '阴雨天'
      }
    })

    expect(createScene.statusCode).toBe(200)
    expect(createScene.json.scenes).toEqual([
      expect.objectContaining({
        id: 1,
        name: '阴雨天'
      })
    ])
    expect(createScene.json.records).toEqual([])
    expect(createScene.json.matrixMeta).toMatchObject({
      pointCount: 1200,
      columnCount: 40,
      rowCount: 30,
      groupSize: 4
    })
  })

  it('loads an acceptance plan from json for the frontend even without ROS', async () => {
    const app = createApp({
      databasePath: ':memory:',
      acceptancePlanLoader: async () =>
        JSON.stringify({
          areas: [
            {
              area_index: 1,
              groups: [
                {
                  points: [
                    {
                      global_idx: 111,
                      global_row: 0,
                      global_col: 0,
                      local_idx: 1,
                      x: -1,
                      y: 2,
                      z: 3,
                      angle: -45,
                      checkerboard_parity: 1,
                      is_checkerboard_member: true
                    },
                    {
                      global_idx: 3,
                      global_row: 0,
                      global_col: 1,
                      local_idx: 2,
                      x: -2,
                      y: 2,
                      z: 3,
                      angle: -45,
                      checkerboard_parity: 0,
                      is_checkerboard_member: true
                    }
                  ]
                }
              ]
            },
            {
              area_index: 3,
              groups: [
                {
                  points: [
                    {
                      global_idx: 120,
                      global_row: 1,
                      global_col: 0,
                      local_idx: 1,
                      x: -1,
                      y: 3,
                      z: 4,
                      angle: -45,
                      checkerboard_parity: 1,
                      is_checkerboard_member: true
                    },
                    {
                      global_idx: 9,
                      global_row: 1,
                      global_col: 1,
                      local_idx: 2,
                      x: -2,
                      y: 3,
                      z: 4,
                      angle: -45,
                      checkerboard_parity: 0,
                      is_checkerboard_member: true
                    }
                  ]
                }
              ]
            }
          ]
        })
    })
    closers.push(app.close)

    const response = await app.inject({
      method: 'GET',
      path: '/api/acceptance-plan'
    })

    expect(response.statusCode).toBe(200)
    expect(response.json.plan).toMatchObject({
      pointCount: 4,
      rowCount: 2,
      columnCount: 2,
      maxPointId: 120
    })
    expect(response.json.plan.areas).toEqual([
      { areaIndex: 1, pointIds: [111, 3] },
      { areaIndex: 3, pointIds: [120, 9] }
    ])
  })

  it('persists failed state, note, and explicit success records for one scene', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '强光'
      }
    })

    const failed = await app.inject({
      method: 'PUT',
      path: '/api/points/6/state',
      body: {
        sceneId: 1,
        isFailed: true
      }
    })

    expect(failed.statusCode).toBe(200)
    expect(failed.json.records).toContainEqual(
      expect.objectContaining({
        pointId: 6,
        sceneId: 1,
        isFailed: true,
        note: ''
      })
    )

    const withNote = await app.inject({
      method: 'PUT',
      path: '/api/points/6/note',
      body: {
        sceneId: 1,
        note: '亮斑异常'
      }
    })

    expect(withNote.statusCode).toBe(200)
    expect(withNote.json.records).toContainEqual(
      expect.objectContaining({
        pointId: 6,
        sceneId: 1,
        isFailed: true,
        note: '亮斑异常'
      })
    )

    const recovered = await app.inject({
      method: 'PUT',
      path: '/api/points/6/state',
      body: {
        sceneId: 1,
        isFailed: false
      }
    })

    expect(recovered.statusCode).toBe(200)
    expect(recovered.json.records).toContainEqual(
      expect.objectContaining({
        pointId: 6,
        sceneId: 1,
        isFailed: false,
        note: '亮斑异常'
      })
    )
    expect(recovered.json.stats.sceneStats[0]).toEqual(
      expect.objectContaining({
        recordedCount: 1,
        recordedSuccessCount: 1,
        defaultSuccessCount: 1199,
        failureCount: 0,
        successCount: 1200,
        notedCount: 1
      })
    )
  })

  it('updates row and column counts and returns matching matrix metadata', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    const write = await app.inject({
      method: 'PUT',
      path: '/api/settings',
      body: {
        rowCount: 8,
        columnCount: 32
      }
    })

    expect(write.statusCode).toBe(200)
    expect(write.json.settings.pointCount).toBe(256)
    expect(write.json.matrixMeta).toMatchObject({
      pointCount: 256,
      columnCount: 32,
      rowCount: 8,
      groupSize: 4
    })
    expect(write.json.stats.totalPoints).toBe(256)
  })

  it('deletes one scene and removes its records, save records, and context', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '阴天'
      }
    })

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '强光'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/state',
      body: {
        sceneId: 1,
        isFailed: true
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/note',
      body: {
        sceneId: 1,
        note: '待删除场景记录'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/workbench-context',
      body: {
        sceneId: 1,
        selectedPointId: 6
      }
    })

    await app.inject({
      method: 'POST',
      path: '/api/group-save/manual',
      body: {
        sceneId: 1,
        selectedPointId: 6
      }
    })

    const deleted = await app.inject({
      method: 'DELETE',
      path: '/api/scenes/1'
    })

    expect(deleted.statusCode).toBe(200)
    expect(deleted.json.scenes).toEqual([
      expect.objectContaining({
        id: 2,
        name: '强光'
      })
    ])
    expect(deleted.json.records).toEqual([])
    expect(deleted.json.stats.sceneStats).toEqual([
      expect.objectContaining({
        sceneId: 2,
        sceneName: '强光'
      })
    ])

    const form = await app.inject({
      method: 'GET',
      path: '/api/form'
    })

    expect(form.statusCode).toBe(200)
    expect(form.json.scenes).toHaveLength(1)
    expect(form.json.scenes[0]).toEqual(
      expect.objectContaining({
        id: 2,
        name: '强光'
      })
    )
    expect(form.json.records).toEqual([])
  })

  it('resets one scene back to default and clears records, notes, and group saves', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '阴天'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/state',
      body: {
        sceneId: 1,
        isFailed: true
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/note',
      body: {
        sceneId: 1,
        note: '待恢复默认'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/workbench-context',
      body: {
        sceneId: 1,
        selectedPointId: 6
      }
    })

    await app.inject({
      method: 'POST',
      path: '/api/group-save/manual',
      body: {
        sceneId: 1,
        selectedPointId: 6
      }
    })

    const reset = await app.inject({
      method: 'POST',
      path: '/api/scenes/1/reset'
    })

    expect(reset.statusCode).toBe(200)
    expect(reset.json.scenes).toEqual([
      expect.objectContaining({
        id: 1,
        name: '阴天'
      })
    ])
    expect(reset.json.records).toEqual([])
    expect(reset.json.stats.sceneStats).toEqual([
      expect.objectContaining({
        sceneId: 1,
        recordedCount: 0,
        failureCount: 0,
        notedCount: 0,
        successCount: 1200
      })
    ])

    const form = await app.inject({
      method: 'GET',
      path: '/api/form'
    })

    expect(form.statusCode).toBe(200)
    expect(form.json.scenes).toHaveLength(1)
    expect(form.json.records).toEqual([])
  })

  it('stores workbench context and saves the current group snapshot manually', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '阴天'
      }
    })

    const context = await app.inject({
      method: 'PUT',
      path: '/api/workbench-context',
      body: {
        sceneId: 1,
        selectedPointId: 6
      }
    })

    expect(context.statusCode).toBe(200)
    expect(context.json).toEqual({ ok: true })

    const saved = await app.inject({
      method: 'POST',
      path: '/api/group-save/manual',
      body: {
        sceneId: 1,
        selectedPointId: 6,
        noteOverrides: [
          {
            pointId: 6,
            note: '当前组人工保存'
          }
        ]
      }
    })

    expect(saved.statusCode).toBe(200)
    expect(saved.json.saveRecord).toEqual(
      expect.objectContaining({
        sceneId: 1,
        selectedPointId: 6,
        groupIndex: 2,
        source: 'manual'
      })
    )
    expect(saved.json.form.records).toContainEqual(
      expect.objectContaining({
        pointId: 6,
        sceneId: 1,
        note: '当前组人工保存'
      })
    )
  })

  it('accepts ROS auto-save payload, stores capture image, and returns one save record summary', async () => {
    const captureDir = mkdtempSync(path.join(tmpdir(), 'acceptance-captures-'))
    tempDirs.push(captureDir)
    const app = createApp({ databasePath: ':memory:', captureDir })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '阴天'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/workbench-context',
      body: {
        sceneId: 1,
        selectedPointId: 6
      }
    })

    const autoSaved = await app.inject({
      method: 'POST',
      path: '/api/group-save/auto',
      body: {
        sourceTopic: '/web/point_ai/save_acceptance_record',
        rawSignal: 'save-now',
        capturedAt: '1712499999.123',
        mimeType: 'image/jpeg',
        rgbBase64: Buffer.from('jpeg-test-data').toString('base64'),
        detectedPoints: [
          {
            idx: 1,
            pixCoord: [120, 240],
            worldCoord: [0.1, 0.2, 0.3],
            angle: 12.5,
            isShuiguan: false
          }
        ]
      }
    })

    expect(autoSaved.statusCode).toBe(200)
    expect(autoSaved.json.saveRecord).toEqual(
      expect.objectContaining({
        sceneId: 1,
        selectedPointId: 6,
        groupIndex: 2,
        source: 'ros',
        rgbPath: expect.any(String)
      })
    )
    expect(existsSync(autoSaved.json.saveRecord.rgbPath)).toBe(true)
  })

  it('accepts ROS auto-save without image when explicit scene and sparse point are provided', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '联动场景'
      }
    })

    const autoSaved = await app.inject({
      method: 'POST',
      path: '/api/group-save/auto',
      body: {
        sceneId: 1,
        selectedPointId: 1301,
        groupIndex: 56,
        sourceTopic: '/pointAI/result_image',
        detectedPoints: []
      }
    })

    expect(autoSaved.statusCode).toBe(200)
    expect(autoSaved.json.saveRecord).toEqual(
      expect.objectContaining({
        sceneId: 1,
        selectedPointId: 1301,
        groupIndex: 56,
        source: 'ros',
        rgbPath: ''
      })
    )
  })

  it('exports one selected scene with coordinates and note', async () => {
    const captureDir = mkdtempSync(path.join(tmpdir(), 'acceptance-export-captures-'))
    tempDirs.push(captureDir)
    const app = createApp({ databasePath: ':memory:', captureDir })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '阴雨天'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/state',
      body: {
        sceneId: 1,
        isFailed: true
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/note',
      body: {
        sceneId: 1,
        note: '亮斑异常'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/workbench-context',
      body: {
        sceneId: 1,
        selectedPointId: 6
      }
    })

    await app.inject({
      method: 'POST',
      path: '/api/group-save/auto',
      body: {
        sourceTopic: '/web/point_ai/save_acceptance_record',
        rawSignal: 'save-now',
        capturedAt: '1712499999.123',
        mimeType: 'image/jpeg',
        rgbBase64: Buffer.from('old-export-image').toString('base64'),
        detectedPoints: []
      }
    })

    await app.inject({
      method: 'POST',
      path: '/api/group-save/auto',
      body: {
        sourceTopic: '/web/point_ai/save_acceptance_record',
        rawSignal: 'save-now',
        capturedAt: '1712500000.456',
        mimeType: 'image/jpeg',
        rgbBase64: Buffer.from('new-export-image').toString('base64'),
        detectedPoints: []
      }
    })

    const response = await app.inject({
      method: 'GET',
      path: '/api/export.xlsx?scope=scene&sceneId=1'
    })

    expect(response.statusCode).toBe(200)
    expect(response.headers['content-type']).toContain('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    expect(response.headers['content-disposition']).toMatch(/attachment; filename="\d{8}-\d{6}\.xlsx"/)

    const workbook = XLSX.read(response.body, { type: 'buffer' })
    const sheet = workbook.Sheets['阴雨天']
    const rows = XLSX.utils.sheet_to_json<(string | number)[]>(sheet, { header: 1 })
    expect(rows[0]).toEqual(['组号', '点号', 'X', 'Y', '结果', '备注', '更新时间', '组图片'])
    expect(
      rows.find(
        (row) =>
          row[0] === 2 &&
          row[1] === 6 &&
          row[2] === '02' &&
          row[3] === '03'
      )
    ).toEqual([
      2,
      6,
      '02',
      '03',
      '失败',
      '亮斑异常',
      expect.any(String),
      ''
    ])
    expect(rows.at(-3)).toEqual(['导出时间', expect.any(String)])
    expect(rows.at(-2)).toEqual(['全局绑扎次数', '绑扎点位总数', '成功绑扎点位', '错绑', '成功率'])
    expect(rows.at(-1)).toEqual([2, 1200, 1199, 1, '99.92%'])

    const excelWorkbook = new ExcelJS.Workbook()
    await excelWorkbook.xlsx.load(response.body as Buffer)
    const worksheet = excelWorkbook.getWorksheet('阴雨天')
    expect(worksheet?.getImages()).toHaveLength(1)
    expect(excelWorkbook.model.media).toHaveLength(1)
    expect(Buffer.from(excelWorkbook.model.media[0]!.buffer).toString()).toContain('new-export-image')
  })

  it('exports all scenes into one workbook with one sheet per scene', async () => {
    const app = createApp({ databasePath: ':memory:' })
    closers.push(app.close)

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '阴雨天'
      }
    })

    await app.inject({
      method: 'POST' as never,
      path: '/api/scenes',
      body: {
        name: '强光'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/state',
      body: {
        sceneId: 1,
        isFailed: true
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/6/note',
      body: {
        sceneId: 1,
        note: '亮斑异常'
      }
    })

    await app.inject({
      method: 'PUT',
      path: '/api/points/8/state',
      body: {
        sceneId: 2,
        isFailed: true
      }
    })

    const response = await app.inject({
      method: 'GET',
      path: '/api/export.xlsx?scope=all'
    })

    expect(response.statusCode).toBe(200)
    expect(response.headers['content-disposition']).toMatch(/attachment; filename="\d{8}-\d{6}\.xlsx"/)

    const workbook = XLSX.read(response.body, { type: 'buffer' })
    expect(workbook.SheetNames).toEqual(['阴雨天', '强光'])

    const rainyRows = XLSX.utils.sheet_to_json<(string | number)[]>(workbook.Sheets['阴雨天'], { header: 1 })
    const strongRows = XLSX.utils.sheet_to_json<(string | number)[]>(workbook.Sheets['强光'], { header: 1 })

    expect(
      rainyRows.find(
        (row) =>
          row[0] === 2 &&
          row[1] === 6 &&
          row[2] === '02' &&
          row[3] === '03'
      )
    ).toEqual([2, 6, '02', '03', '失败', '亮斑异常', expect.any(String), ''])
    expect(
      strongRows.find(
        (row) =>
          row[0] === 2 &&
          row[1] === 8 &&
          row[2] === '02' &&
          row[3] === '04'
      )
    ).toEqual([2, 8, '02', '04', '失败', '', expect.any(String), ''])
    expect(rainyRows.at(-3)).toEqual(['导出时间', expect.any(String)])
    expect(rainyRows.at(-2)).toEqual(['全局绑扎次数', '绑扎点位总数', '成功绑扎点位', '错绑', '成功率'])
    expect(rainyRows.at(-1)).toEqual([0, 1200, 1199, 1, '99.92%'])
    expect(strongRows.at(-1)).toEqual([0, 1200, 1199, 1, '99.92%'])
  })
})

