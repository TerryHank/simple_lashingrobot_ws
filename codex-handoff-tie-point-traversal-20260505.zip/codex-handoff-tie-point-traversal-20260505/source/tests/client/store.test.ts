import { afterEach, describe, expect, it, vi } from 'vitest'
import { createAcceptanceStore, createInitialSelection } from '../../src/client/store.js'
import type { AcceptancePlanPayload, FormDataPayload } from '../../src/shared/types.js'

function createFormData(overrides?: Partial<FormDataPayload>): FormDataPayload {
  return {
    settings: {
      pointCount: 10,
      columnCount: 4,
      rowCount: 3,
      groupSize: 4
    },
    scenes: [
      {
        id: 1,
        name: '阴雨天',
        createdAt: '2026-04-04T00:00:00.000Z'
      }
    ],
    records: [],
    stats: {
      totalPoints: 10,
      totalScenes: 1,
      sceneStats: [
        {
          sceneId: 1,
          sceneName: '阴雨天',
          recordedCount: 0,
          recordedSuccessCount: 0,
          defaultSuccessCount: 10,
          failureCount: 0,
          successCount: 10,
          notedCount: 0
        }
      ]
    },
    matrixMeta: {
      pointCount: 10,
      columnCount: 4,
      rowCount: 3,
      groupSize: 4
    },
    ...overrides
  }
}

function createApiStub() {
  return {
    fetchFormData: vi.fn(),
    createScene: vi.fn(),
    deleteScene: vi.fn(),
    resetScene: vi.fn(),
    updatePointState: vi.fn(),
    updatePointNote: vi.fn(),
    updateSettings: vi.fn(),
    updateWorkbenchContext: vi.fn(),
    saveCurrentGroup: vi.fn(),
    saveAutoGroup: vi.fn()
  }
}

function createAcceptancePlan(): AcceptancePlanPayload {
  return {
    points: [
      { pointId: 3, areaIndex: 2, localIndex: 1, x: 2, y: 0, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 1, areaIndex: 2, localIndex: 2, x: 3, y: 0, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 5, areaIndex: 2, localIndex: 3, x: 2, y: 1, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 2, areaIndex: 2, localIndex: 4, x: 3, y: 1, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 15, areaIndex: 4, localIndex: 1, x: 4, y: 0, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 13, areaIndex: 4, localIndex: 2, x: 5, y: 0, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 16, areaIndex: 4, localIndex: 3, x: 4, y: 1, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 14, areaIndex: 4, localIndex: 4, x: 5, y: 1, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true }
    ],
    areas: [
      { areaIndex: 2, pointIds: [3, 1, 5, 2] },
      { areaIndex: 4, pointIds: [15, 13, 16, 14] }
    ],
    pointCount: 8,
    maxPointId: 16,
    rowCount: 2,
    columnCount: 6,
    receivedAt: '2026-04-17T08:00:00.000Z'
  }
}

function createHighPointAcceptancePlan(): AcceptancePlanPayload {
  return {
    points: [
      { pointId: 251, areaIndex: 80, localIndex: 1, x: 0, y: 0, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 0, isCheckerboardMember: true },
      { pointId: 252, areaIndex: 80, localIndex: 2, x: 1, y: 0, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 253, areaIndex: 80, localIndex: 3, x: 0, y: 1, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 1, isCheckerboardMember: true },
      { pointId: 254, areaIndex: 80, localIndex: 4, x: 1, y: 1, worldCoord: [0, 0, 0], angle: 0, checkerboardParity: 0, isCheckerboardMember: true }
    ],
    areas: [
      { areaIndex: 80, pointIds: [251, 252, 253, 254] }
    ],
    pointCount: 4,
    maxPointId: 254,
    rowCount: 2,
    columnCount: 2,
    receivedAt: '2026-04-17T09:00:00.000Z'
  }
}

const originalWindow = globalThis.window

afterEach(() => {
  if (originalWindow) {
    globalThis.window = originalWindow
  } else {
    Reflect.deleteProperty(globalThis, 'window')
  }
})

describe('client store helpers', () => {
  it('defaults to point 1 when no previous selection exists', () => {
    expect(createInitialSelection(undefined)).toBe(1)
  })

  it('keeps a valid previous selection', () => {
    expect(createInitialSelection(327)).toBe(327)
  })
})

describe('acceptance store', () => {
  it('derives current group and matrix meta from point count', async () => {
    const apiStub = createApiStub()
    const store = createAcceptanceStore(apiStub as never)

    store.applyFormData(createFormData())
    await store.goToPoint(6)

    expect(store.currentGroupPoints.value.map((point) => point.pointId)).toEqual([5, 6, 3, 4])
    expect(store.matrixMeta.value).toMatchObject({
      pointCount: 10,
      columnCount: 4,
      rowCount: 3,
      groupSize: 4
    })
    expect(store.gridPoints.value.find((point) => point.pointId === 6)).toMatchObject({
      x: 1,
      y: 2,
      isCurrent: true,
      isInCurrentGroup: true
    })
  })

  it('toggles point failure through the state api and updates the group view', async () => {
    const apiStub = createApiStub()
    apiStub.updatePointState.mockResolvedValue(
      createFormData({
        records: [
          {
            pointId: 6,
            sceneId: 1,
            isFailed: true,
            note: '',
            updatedAt: '2026-04-04T00:05:00.000Z'
          }
        ],
        stats: {
          totalPoints: 10,
          totalScenes: 1,
          sceneStats: [
            {
              sceneId: 1,
              sceneName: '阴雨天',
              recordedCount: 1,
              recordedSuccessCount: 0,
              defaultSuccessCount: 9,
              failureCount: 1,
              successCount: 9,
              notedCount: 0
            }
          ]
        }
      })
    )

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(createFormData())
    await store.goToPoint(6)
    await store.togglePointFailed()

    expect(apiStub.updatePointState).toHaveBeenCalledWith({
      pointId: 6,
      sceneId: 1,
      isFailed: true
    })
    expect(store.currentGroupPoints.value.find((point) => point.pointId === 6)).toMatchObject({
      isFailed: true,
      hasRecord: true
    })
    expect(store.activeSceneStats.value).toMatchObject({
      failureCount: 1,
      successCount: 9
    })
  })

  it('saves the current group before moving to the next group', async () => {
    const apiStub = createApiStub()
    apiStub.saveCurrentGroup.mockResolvedValue({
      form: createFormData({
        records: [
          {
            pointId: 6,
            sceneId: 1,
            isFailed: false,
            note: '历史备注',
            updatedAt: '2026-04-04T00:06:00.000Z'
          }
        ],
        stats: {
          totalPoints: 10,
          totalScenes: 1,
          sceneStats: [
            {
              sceneId: 1,
              sceneName: '阴雨天',
              recordedCount: 1,
              recordedSuccessCount: 1,
              defaultSuccessCount: 9,
              failureCount: 0,
              successCount: 10,
              notedCount: 1
            }
          ]
        }
      }),
      saveRecord: {
        id: 1,
        sceneId: 1,
        selectedPointId: 6,
        groupIndex: 2,
        source: 'manual',
        rgbPath: '',
        createdAt: '2026-04-04T00:06:00.000Z'
      }
    })

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(createFormData())
    await store.goToPoint(6)
    await store.saveCurrentGroupAndMoveNext([{ pointId: 6, note: '历史备注' }])

    expect(apiStub.saveCurrentGroup).toHaveBeenCalledWith({
      sceneId: 1,
      selectedPointId: 6,
      noteOverrides: [{ pointId: 6, note: '历史备注' }]
    })
    expect(store.getPointState(6)).toMatchObject({
      hasRecord: true,
      isFailed: false,
      note: '历史备注'
    })
    expect(store.selectedPointId.value).toBe(7)
    expect(store.currentGroupPoints.value.map((point) => point.pointId)).toEqual([7, 8, 9, 10])
  })

  it('exports either the active scene or all scenes into one workbook url', () => {
    const apiStub = createApiStub()
    const open = vi.fn()
    globalThis.window = { open } as never

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(
      createFormData({
        scenes: [
          {
            id: 1,
            name: '阴雨天',
            createdAt: '2026-04-04T00:00:00.000Z'
          },
          {
            id: 2,
            name: '强光',
            createdAt: '2026-04-04T00:01:00.000Z'
          }
        ]
      })
    )

    store.exportExcel('scene')
    store.exportExcel('all')

    expect(open).toHaveBeenNthCalledWith(1, '/api/export.xlsx?scope=scene&sceneId=1', '_blank')
    expect(open).toHaveBeenNthCalledWith(2, '/api/export.xlsx?scope=all', '_blank')
  })

  it('updates matrix dimensions through the settings api and clamps the current point', async () => {
    const apiStub = createApiStub()
    apiStub.updateSettings.mockResolvedValue(
      createFormData({
        settings: {
          pointCount: 16,
          columnCount: 4,
          rowCount: 4,
          groupSize: 4
        },
        stats: {
          totalPoints: 16,
          totalScenes: 1,
          sceneStats: [
            {
              sceneId: 1,
              sceneName: '阴雨天',
              recordedCount: 0,
              recordedSuccessCount: 0,
              defaultSuccessCount: 16,
              failureCount: 0,
              successCount: 16,
              notedCount: 0
            }
          ]
        },
        matrixMeta: {
          pointCount: 16,
          columnCount: 4,
          rowCount: 4,
          groupSize: 4
        }
      })
    )

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(createFormData())
    await store.goToPoint(10)
    await store.updateGridDimensions({ rowCount: 4, columnCount: 4 })

    expect(apiStub.updateSettings).toHaveBeenCalledWith({
      rowCount: 4,
      columnCount: 4
    })
    expect(store.settings.value).toMatchObject({
      pointCount: 16,
      rowCount: 4,
      columnCount: 4
    })
    expect(store.selectedPointId.value).toBe(10)
  })

  it('uses sparse ROS acceptance plans for grouping and navigation', async () => {
    const apiStub = createApiStub()
    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(createFormData())

    await store.applyAcceptancePlan(createAcceptancePlan())

    expect(store.matrixMeta.value).toMatchObject({
      pointCount: 8,
      rowCount: 2,
      columnCount: 6
    })
    expect(store.groupCount.value).toBe(4)
    expect(store.currentGroupIndex.value).toBe(2)
    expect(store.currentGroupPoints.value.map((point) => point.pointId)).toEqual([5, 2, 3, 1])
    expect(store.getGroupIndexForPoint(14)).toBe(4)

    await store.moveGroup(1)

    expect(store.currentGroupIndex.value).toBe(4)
    expect(store.currentGroupPoints.value.map((point) => point.pointId)).toEqual([16, 14, 15, 13])
    expect(store.gridPoints.value.find((point) => point.pointId === 3)?.hoverLabel).toContain('世界 0, 0, 0')
  })

  it('moves to the next available sparse ROS area after saving the current group', async () => {
    const apiStub = createApiStub()
    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(createFormData())

    await store.applyAcceptancePlan(createAcceptancePlan())
    await store.saveCurrentGroupAndMoveNext()

    expect(store.currentGroupIndex.value).toBe(4)
    expect(store.selectedPointId.value).toBe(15)
  })

  it('keeps sparse planned point ids after toggling a point state', async () => {
    const apiStub = createApiStub()
    apiStub.updatePointState.mockResolvedValue(
      createFormData({
        records: [
          {
            pointId: 251,
            sceneId: 1,
            isFailed: true,
            note: '',
            updatedAt: '2026-04-17T09:02:00.000Z'
          }
        ]
      })
    )

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(createFormData())
    await store.applyAcceptancePlan(createHighPointAcceptancePlan())
    await store.goToPoint(251)
    await store.togglePointFailed()

    expect(apiStub.updatePointState).toHaveBeenCalledWith({
      pointId: 251,
      sceneId: 1,
      isFailed: true
    })
    expect(store.selectedPointId.value).toBe(251)
    expect(store.currentGroupPoints.value.find((point) => point.pointId === 251)).toMatchObject({
      isFailed: true,
      hasRecord: true
    })
  })

  it('auto-saves the finished ROS area by explicit area index instead of current selection', async () => {
    const apiStub = createApiStub()
    apiStub.saveAutoGroup.mockResolvedValue({
      saveRecord: {
        id: 10,
        sceneId: 1,
        selectedPointId: 3,
        groupIndex: 2,
        source: 'ros',
        rgbPath: '',
        createdAt: '2026-04-17T09:00:00.000Z'
      }
    })

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(createFormData())
    await store.applyAcceptancePlan(createAcceptancePlan())
    await store.goToGroup(4)
    await store.saveGroupFromRos({
      groupIndex: 2,
      sourceTopic: '/pointAI/result_image',
      capturedAt: '2026-04-17T09:00:00.000Z',
      detectedPoints: []
    })

    expect(store.currentGroupIndex.value).toBe(4)
    expect(apiStub.saveAutoGroup).toHaveBeenCalledWith({
      sceneId: 1,
      selectedPointId: 3,
      groupIndex: 2,
      sourceTopic: '/pointAI/result_image',
      rawSignal: undefined,
      capturedAt: '2026-04-17T09:00:00.000Z',
      mimeType: undefined,
      rgbBase64: undefined,
      detectedPoints: []
    })
  })

  it('deletes one scene and falls back to the next available scene', async () => {
    const apiStub = createApiStub()
    apiStub.deleteScene.mockResolvedValue(
      createFormData({
        scenes: [
          {
            id: 2,
            name: '强光',
            createdAt: '2026-04-04T00:01:00.000Z'
          }
        ],
        stats: {
          totalPoints: 10,
          totalScenes: 1,
          sceneStats: [
            {
              sceneId: 2,
              sceneName: '强光',
              recordedCount: 0,
              recordedSuccessCount: 0,
              defaultSuccessCount: 10,
              failureCount: 0,
              successCount: 10,
              notedCount: 0
            }
          ]
        }
      })
    )

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(
      createFormData({
        scenes: [
          {
            id: 1,
            name: '阴雨天',
            createdAt: '2026-04-04T00:00:00.000Z'
          },
          {
            id: 2,
            name: '强光',
            createdAt: '2026-04-04T00:01:00.000Z'
          }
        ],
        stats: {
          totalPoints: 10,
          totalScenes: 2,
          sceneStats: [
            {
              sceneId: 1,
              sceneName: '阴雨天',
              recordedCount: 0,
              recordedSuccessCount: 0,
              defaultSuccessCount: 10,
              failureCount: 0,
              successCount: 10,
              notedCount: 0
            },
            {
              sceneId: 2,
              sceneName: '强光',
              recordedCount: 0,
              recordedSuccessCount: 0,
              defaultSuccessCount: 10,
              failureCount: 0,
              successCount: 10,
              notedCount: 0
            }
          ]
        }
      })
    )

    await store.deleteScene(1)

    expect(apiStub.deleteScene).toHaveBeenCalledWith(1)
    expect(store.scenes.value.map((scene) => scene.id)).toEqual([2])
    expect(store.activeSceneId.value).toBe(2)
  })

  it('resets the current scene back to the default state and jumps to the first point', async () => {
    const apiStub = createApiStub()
    apiStub.resetScene.mockResolvedValue(
      createFormData({
        records: [],
        stats: {
          totalPoints: 10,
          totalScenes: 1,
          sceneStats: [
            {
              sceneId: 1,
              sceneName: '阴雨天',
              recordedCount: 0,
              recordedSuccessCount: 0,
              defaultSuccessCount: 10,
              failureCount: 0,
              successCount: 10,
              notedCount: 0
            }
          ]
        }
      })
    )

    const store = createAcceptanceStore(apiStub as never)
    store.applyFormData(
      createFormData({
        records: [
          {
            pointId: 6,
            sceneId: 1,
            isFailed: true,
            note: '需要清空',
            updatedAt: '2026-04-04T00:08:00.000Z'
          }
        ],
        stats: {
          totalPoints: 10,
          totalScenes: 1,
          sceneStats: [
            {
              sceneId: 1,
              sceneName: '阴雨天',
              recordedCount: 1,
              recordedSuccessCount: 0,
              defaultSuccessCount: 9,
              failureCount: 1,
              successCount: 9,
              notedCount: 1
            }
          ]
        }
      })
    )

    await store.goToPoint(6)
    store.setHoveredPoint(6)
    await store.resetScene(1)

    expect(apiStub.resetScene).toHaveBeenCalledWith(1)
    expect(store.selectedPointId.value).toBe(1)
    expect(store.hoveredPointId.value).toBeNull()
    expect(store.getPointState(6)).toMatchObject({
      hasRecord: false,
      isFailed: false,
      note: ''
    })
    expect(store.activeSceneStats.value).toMatchObject({
      recordedCount: 0,
      failureCount: 0,
      notedCount: 0
    })
  })

  it('moves into an overlapping edge group instead of snapping back to the previous group', async () => {
    const apiStub = createApiStub()
    const store = createAcceptanceStore(apiStub as never)

    store.applyFormData(
      createFormData({
        settings: {
          pointCount: 81,
          columnCount: 9,
          rowCount: 9,
          groupSize: 4
        },
        stats: {
          totalPoints: 81,
          totalScenes: 1,
          sceneStats: [
            {
              sceneId: 1,
              sceneName: '阴雨天',
              recordedCount: 0,
              recordedSuccessCount: 0,
              defaultSuccessCount: 81,
              failureCount: 0,
              successCount: 81,
              notedCount: 0
            }
          ]
        },
        matrixMeta: {
          pointCount: 81,
          columnCount: 9,
          rowCount: 9,
          groupSize: 4
        }
      })
    )

    await store.goToGroup(5)

    expect(store.currentGroupIndex.value).toBe(5)
    expect(store.selectedPointId.value).toBe(17)
    expect(store.currentGroupPoints.value.map((point) => point.pointId)).toEqual([17, 18, 15, 16])
  })
})

