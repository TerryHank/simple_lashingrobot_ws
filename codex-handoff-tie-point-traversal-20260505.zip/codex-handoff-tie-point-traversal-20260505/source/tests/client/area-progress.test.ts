import { describe, expect, it } from 'vitest'
import {
  createDefaultAreaProgressState,
  deriveAreaProgressUpdate,
  resolveAreaProgressGroupIndex
} from '../../src/client/area-progress.js'
import { normalizeAreaProgress } from '../../src/shared/ros-messages.js'

describe('area progress normalization', () => {
  it('normalizes valid area progress payloads', () => {
    expect(
      normalizeAreaProgress({
        current_area_index: '2',
        total_area_count: 8,
        just_finished_area_index: 1,
        ready_for_next_area: 1,
        all_done: false
      })
    ).toEqual({
      current_area_index: 2,
      total_area_count: 8,
      just_finished_area_index: 1,
      ready_for_next_area: true,
      all_done: false
    })
  })

  it('rejects invalid area progress payloads', () => {
    expect(
      normalizeAreaProgress({
        current_area_index: -1,
        total_area_count: 8,
        just_finished_area_index: 1,
        ready_for_next_area: false,
        all_done: false
      })
    ).toBeNull()

    expect(
      normalizeAreaProgress({
        current_area_index: 1,
        total_area_count: 8,
        just_finished_area_index: 1,
        ready_for_next_area: 'yes',
        all_done: false
      })
    ).toBeNull()
  })
})

describe('area progress pulse behavior', () => {
  it('pulses only when just_finished_area_index changes to a positive value', () => {
    const baseState = createDefaultAreaProgressState()

    const firstUpdate = deriveAreaProgressUpdate(baseState, {
      current_area_index: 2,
      total_area_count: 8,
      just_finished_area_index: 2,
      ready_for_next_area: false,
      all_done: false
    })
    expect(firstUpdate.shouldPulse).toBe(true)
    expect(firstUpdate.state.justFinishedAreaIndex).toBe(2)

    const sameFinishedUpdate = deriveAreaProgressUpdate(firstUpdate.state, {
      current_area_index: 2,
      total_area_count: 8,
      just_finished_area_index: 2,
      ready_for_next_area: true,
      all_done: false
    })
    expect(sameFinishedUpdate.shouldPulse).toBe(false)

    const resetFinishedUpdate = deriveAreaProgressUpdate(sameFinishedUpdate.state, {
      current_area_index: 3,
      total_area_count: 8,
      just_finished_area_index: 0,
      ready_for_next_area: true,
      all_done: false
    })
    expect(resetFinishedUpdate.shouldPulse).toBe(false)
    expect(resetFinishedUpdate.state.justFinishedAreaIndex).toBeNull()
  })
})

describe('resolveAreaProgressGroupIndex', () => {
  it('uses current_area_index only when it is within range', () => {
    expect(
      resolveAreaProgressGroupIndex(
        {
          currentAreaIndex: 3,
          totalAreaCount: 8,
          justFinishedAreaIndex: 2,
          readyForNextArea: true,
          allDone: false
        },
        8
      )
    ).toBe(3)

    expect(
      resolveAreaProgressGroupIndex(
        {
          currentAreaIndex: 12,
          totalAreaCount: 8,
          justFinishedAreaIndex: 2,
          readyForNextArea: true,
          allDone: false
        },
        8
      )
    ).toBeNull()
  })

  it('pins to the last group only when all_done is true', () => {
    expect(
      resolveAreaProgressGroupIndex(
        {
          currentAreaIndex: 12,
          totalAreaCount: 8,
          justFinishedAreaIndex: 8,
          readyForNextArea: true,
          allDone: true
        },
        8
      )
    ).toBe(8)
  })
})
