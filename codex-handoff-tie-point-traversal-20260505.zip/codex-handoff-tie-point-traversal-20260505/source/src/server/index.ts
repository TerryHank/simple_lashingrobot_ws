import { mkdirSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createApp } from './http.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const projectRoot = path.resolve(__dirname, '../../')
const staticDir = path.join(projectRoot, 'docs', '.vitepress', 'dist')
const dataDir = path.join(projectRoot, 'data')
const captureDir = path.join(dataDir, 'captures')
const databasePath = path.join(dataDir, 'acceptance.db')
const port = Number(process.env.PORT ?? 4173)
const acceptancePlanPath =
  process.env.ACCEPTANCE_PLAN_PATH ??
  '/home/hyq-/simple_lashingrobot_ws/src/chassis_ctrl/data/pseudo_slam_bind_path.json'
const acceptancePlanSshTarget =
  process.env.ACCEPTANCE_PLAN_SSH_TARGET ??
  'hyq-@192.168.6.99'

mkdirSync(dataDir, { recursive: true })
mkdirSync(captureDir, { recursive: true })

const app = createApp({
  databasePath,
  staticDir,
  captureDir,
  acceptancePlanPath,
  acceptancePlanSshTarget
})

app.server.listen(port, '0.0.0.0', () => {
  console.log(`Acceptance form server listening on http://0.0.0.0:${port}`)
})
