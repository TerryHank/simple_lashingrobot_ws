import { existsSync } from 'node:fs'
import path from 'node:path'
import type { DatabaseSync } from 'node:sqlite'
import ExcelJS from 'exceljs'
import { DEFAULT_POINT_COUNT, GRID_COLUMNS, GRID_ROWS, GROUP_SIZE, MAX_POINT_COUNT } from '../shared/constants.js'
import {
  formatAxisValue,
  getGroupCount,
  getGroupIndex,
  getGroupPointIds,
  getGroupPointIdsForPoint,
  getExactGridDimensions,
  getPointCountFromGrid,
  getPointCoordinate
} from '../shared/matrix.js'
import { getDisplayPointId } from '../shared/point-display.js'
import { calculateFormStats, calculateSceneStats } from '../shared/progress.js'
import type {
  AutoDetectedPointPayload,
  AutoGroupSaveResponse,
  ExportScope,
  FormDataPayload,
  FormSettings,
  GridDimensionsInput,
  GroupNoteOverride,
  GroupSaveSummary,
  ManualGroupSaveResponse,
  MatrixMeta,
  Scene,
  ScenePointRecord,
  WorkbenchContextPayload
} from '../shared/types.js'
import { ensurePointData } from './db.js'

function getTimestamp() {
  return new Date().toISOString()
}

function formatExportDisplayTime(date = new Date()) {
  const pad = (value: number) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
}

function validateGridDimensions(input: GridDimensionsInput) {
  if (!Number.isInteger(input.rowCount) || input.rowCount < 1 || input.rowCount > MAX_POINT_COUNT) {
    throw new RangeError(`rowCount must be between 1 and ${MAX_POINT_COUNT}`)
  }

  if (!Number.isInteger(input.columnCount) || input.columnCount < 1 || input.columnCount > MAX_POINT_COUNT) {
    throw new RangeError(`columnCount must be between 1 and ${MAX_POINT_COUNT}`)
  }

  const pointCount = getPointCountFromGrid(input.rowCount, input.columnCount)
  if (pointCount < 1 || pointCount > MAX_POINT_COUNT) {
    throw new RangeError(`pointCount must be between 1 and ${MAX_POINT_COUNT}`)
  }

  return {
    ...input,
    pointCount
  }
}

function mapMatrixMeta(input: { pointCount: number; rowCount: number; columnCount: number }): MatrixMeta {
  return {
    pointCount: input.pointCount,
    columnCount: input.columnCount,
    rowCount: input.rowCount,
    groupSize: GROUP_SIZE
  }
}

function getSettings(database: DatabaseSync): FormSettings {
  const row = database
    .prepare('select point_count, row_count, column_count from settings where id = 1')
    .get() as
    | {
        point_count: number
        row_count: number
        column_count: number
      }
    | undefined

  if (!row) {
    return mapMatrixMeta({
      pointCount: DEFAULT_POINT_COUNT,
      rowCount: GRID_ROWS,
      columnCount: GRID_COLUMNS
    })
  }

  const normalized =
    Number.isInteger(row.row_count) &&
    Number.isInteger(row.column_count) &&
    row.row_count * row.column_count === row.point_count
      ? validateGridDimensions({
          rowCount: row.row_count,
          columnCount: row.column_count
        })
      : {
          ...getExactGridDimensions(row.point_count),
          pointCount: row.point_count
        }

  return mapMatrixMeta(normalized)
}

function validatePointId(database: DatabaseSync, pointId: number) {
  if (!Number.isInteger(pointId) || pointId < 1 || pointId > MAX_POINT_COUNT) {
    throw new RangeError(`pointId must be between 1 and ${MAX_POINT_COUNT}`)
  }

  ensurePointData(database, pointId)
}

function mapSceneRow(row: { id: number; name: string; created_at: string }): Scene {
  return {
    id: row.id,
    name: row.name,
    createdAt: row.created_at
  }
}

function mapScenePointRecordRow(row: {
  point_id: number
  scene_id: number
  is_failed: number
  note: string
  updated_at: string
}): ScenePointRecord {
  return {
    pointId: row.point_id,
    sceneId: row.scene_id,
    isFailed: row.is_failed === 1,
    note: row.note.trim(),
    updatedAt: row.updated_at
  }
}

function getScenes(database: DatabaseSync) {
  return database
    .prepare('select id, name, created_at from scenes order by id asc')
    .all()
    .map((row) => mapSceneRow(row as { id: number; name: string; created_at: string }))
}

function getSceneById(database: DatabaseSync, sceneId: number) {
  const row = database
    .prepare('select id, name, created_at from scenes where id = ?')
    .get(sceneId) as { id: number; name: string; created_at: string } | undefined

  if (!row) {
    throw new RangeError(`sceneId ${sceneId} not found`)
  }

  return mapSceneRow(row)
}

function getScenePointRecords(database: DatabaseSync, _pointCount: number) {
  return database
    .prepare(
      `
        select point_id, scene_id, is_failed, note, updated_at
        from scene_point_records
        order by scene_id asc, point_id asc
      `
    )
    .all()
    .map((row) =>
      mapScenePointRecordRow(
        row as {
          point_id: number
          scene_id: number
          is_failed: number
          note: string
          updated_at: string
        }
      )
    )
}

function getScenePointRecord(database: DatabaseSync, pointId: number, sceneId: number) {
  const row = database
    .prepare(
      `
        select point_id, scene_id, is_failed, note, updated_at
        from scene_point_records
        where point_id = ? and scene_id = ?
      `
    )
    .get(pointId, sceneId) as
    | {
        point_id: number
        scene_id: number
        is_failed: number
        note: string
        updated_at: string
      }
    | undefined

  return row ? mapScenePointRecordRow(row) : undefined
}

function normalizeNoteOverrides(noteOverrides: GroupNoteOverride[] | undefined) {
  if (!Array.isArray(noteOverrides)) {
    return []
  }

  return noteOverrides.map((override) => {
    if (!override || typeof override !== 'object') {
      throw new TypeError('noteOverrides must contain objects')
    }

    const pointId = Number(override.pointId)
    if (!Number.isInteger(pointId) || pointId < 1) {
      throw new RangeError('note override pointId must be a positive integer')
    }

    if (typeof override.note !== 'string') {
      throw new TypeError('note override note must be a string')
    }

    return {
      pointId,
      note: override.note
    }
  })
}

function getWorkbenchContext(database: DatabaseSync) {
  return database.prepare('select scene_id, selected_point_id from workbench_context where id = 1').get() as
    | {
        scene_id: number | null
        selected_point_id: number | null
      }
    | undefined
}

function updatePointTimestamp(database: DatabaseSync, pointId: number, timestamp: string) {
  database.prepare('update points set updated_at = ? where id = ?').run(timestamp, pointId)
}

function buildGroupSnapshot(database: DatabaseSync, input: { sceneId: number; selectedPointId: number }) {
  const settings = getSettings(database)
  const scene = getSceneById(database, input.sceneId)
  if (input.selectedPointId > settings.pointCount) {
    const state = getScenePointRecord(database, input.selectedPointId, input.sceneId)
    return {
      settings,
      scene,
      selectedPointId: input.selectedPointId,
      groupIndex: input.selectedPointId,
      points: [
        {
          pointId: input.selectedPointId,
          x: 0,
          y: 0,
          coordinateLabel: '',
          isFailed: state?.isFailed ?? false,
          note: state?.note ?? '',
          updatedAt: state?.updatedAt ?? ''
        }
      ]
    }
  }

  const groupIndex = getGroupIndex(input.selectedPointId, settings.pointCount, settings.columnCount)
  const pointIds = getGroupPointIdsForPoint(input.selectedPointId, settings.pointCount, settings.columnCount)
  const points = pointIds.map((pointId) => {
    const coordinate = getPointCoordinate(pointId, settings.pointCount, settings.columnCount)
    const state = getScenePointRecord(database, pointId, input.sceneId)

    return {
      pointId,
      x: coordinate.x,
      y: coordinate.y,
      coordinateLabel: `${formatAxisValue(coordinate.x)},${formatAxisValue(coordinate.y)}`,
      isFailed: state?.isFailed ?? false,
      note: state?.note ?? '',
      updatedAt: state?.updatedAt ?? ''
    }
  })

  return {
    settings,
    scene,
    selectedPointId: input.selectedPointId,
    groupIndex,
    points
  }
}

function insertGroupSaveRecord(
  database: DatabaseSync,
  input: {
    sceneId: number
    selectedPointId: number
    groupIndex: number
    source: 'manual' | 'ros'
    rgbPath: string
    payloadJson: string
    createdAt: string
  }
): GroupSaveSummary {
  const result = database
    .prepare(
      `
        insert into group_save_records (scene_id, selected_point_id, group_index, source, rgb_path, payload_json, created_at)
        values (?, ?, ?, ?, ?, ?, ?)
      `
    )
    .run(
      input.sceneId,
      input.selectedPointId,
      input.groupIndex,
      input.source,
      input.rgbPath,
      input.payloadJson,
      input.createdAt
    )

  return {
    id: Number(result.lastInsertRowid),
    sceneId: input.sceneId,
    selectedPointId: input.selectedPointId,
    groupIndex: input.groupIndex,
    source: input.source,
    rgbPath: input.rgbPath,
    createdAt: input.createdAt
  }
}

function sanitizeSheetName(name: string) {
  const normalized = name.replace(/[\\/?*:[\]]/g, ' ').trim().slice(0, 31)
  return normalized || '验收结果'
}

function createUniqueSheetName(name: string, usedNames: Set<string>) {
  const baseName = sanitizeSheetName(name)
  let candidate = baseName
  let index = 2

  while (usedNames.has(candidate)) {
    const suffix = `-${index}`
    const maxBaseLength = Math.max(1, 31 - suffix.length)
    candidate = `${baseName.slice(0, maxBaseLength)}${suffix}`
    index += 1
  }

  usedNames.add(candidate)
  return candidate
}

function createSceneRecordMap(records: ScenePointRecord[], sceneId: number) {
  return new Map(
    records.filter((record) => record.sceneId === sceneId).map((record) => [record.pointId, record])
  )
}

function getLatestGroupImagePaths(database: DatabaseSync, sceneId: number) {
  const rows = database
    .prepare(
      `
        select group_index, rgb_path
        from group_save_records
        where scene_id = ? and rgb_path <> ''
        order by group_index asc, id desc
      `
    )
    .all(sceneId) as Array<{ group_index: number; rgb_path: string }>

  const images = new Map<number, string>()

  for (const row of rows) {
    if (images.has(row.group_index)) {
      continue
    }

    if (!row.rgb_path || !existsSync(row.rgb_path)) {
      continue
    }

    images.set(row.group_index, row.rgb_path)
  }

  return images
}

function getImageExtension(imagePath: string): 'jpeg' | 'png' | null {
  const extension = path.extname(imagePath).toLowerCase()
  if (extension === '.png') {
    return 'png'
  }

  if (extension === '.jpg' || extension === '.jpeg') {
    return 'jpeg'
  }

  return null
}

async function appendSceneSheet(
  workbook: ExcelJS.Workbook,
  input: {
    database: DatabaseSync
    scene: Scene
    pointCount: number
    columnCount: number
    allRecords: ScenePointRecord[]
    totalBindCount: number
    exportTime: string
    usedSheetNames: Set<string>
  }
) {
  const worksheet = workbook.addWorksheet(createUniqueSheetName(input.scene.name, input.usedSheetNames), {
    views: [{ state: 'frozen', ySplit: 1 }],
    properties: {
      defaultRowHeight: 22
    }
  })

  worksheet.columns = [
    { header: '组号', key: 'groupIndex', width: 8 },
    { header: '点号', key: 'pointId', width: 8 },
    { header: 'X', key: 'x', width: 8 },
    { header: 'Y', key: 'y', width: 8 },
    { header: '结果', key: 'status', width: 10 },
    { header: '备注', key: 'note', width: 24 },
    { header: '更新时间', key: 'updatedAt', width: 24 },
    { header: '组图片', key: 'groupImage', width: 18 }
  ]
  worksheet.getColumn(9).width = 14
  worksheet.getColumn(10).width = 14
  worksheet.getColumn(11).width = 14

  const headerRow = worksheet.getRow(1)
  headerRow.font = { bold: true }
  headerRow.alignment = { vertical: 'middle', horizontal: 'center' }
  headerRow.height = 24

  const records = createSceneRecordMap(input.allRecords, input.scene.id)
  const imagePaths = getLatestGroupImagePaths(input.database, input.scene.id)
  const sceneStats = calculateSceneStats(input.pointCount, [input.scene], Array.from(records.values()))[0]
  const groupCount = getGroupCount(input.pointCount, input.columnCount)

  for (let groupIndex = 1; groupIndex <= groupCount; groupIndex += 1) {
    const groupPointIds = [...getGroupPointIds(groupIndex, input.pointCount, input.columnCount)].sort((left, right) => left - right)
    const startRow = worksheet.rowCount + 1

    for (const pointId of groupPointIds) {
      const coordinate = getPointCoordinate(pointId, input.pointCount, input.columnCount)
      const record = records.get(pointId)
      const row = worksheet.addRow([
        groupIndex,
        getDisplayPointId(pointId),
        formatAxisValue(coordinate.x),
        formatAxisValue(coordinate.y),
        record?.isFailed ? '失败' : '成功',
        record?.note ?? '',
        record?.updatedAt ?? '',
        ''
      ])

      row.alignment = {
        vertical: 'middle',
        horizontal: 'center',
        wrapText: true
      }
      row.getCell(6).alignment = {
        vertical: 'middle',
        horizontal: 'left',
        wrapText: true
      }
      row.height = 30
    }

    const imagePath = imagePaths.get(groupIndex)
    if (imagePath) {
      const extension = getImageExtension(imagePath)
      if (extension) {
        const imageId = workbook.addImage({
          filename: imagePath,
          extension
        })
        const endRow = worksheet.rowCount

        worksheet.addImage(imageId, `H${startRow}:K${endRow}`)
      }
    }

    worksheet.addRow([])
  }

  worksheet.addRow([])
  worksheet.addRow(['导出时间', input.exportTime])
  worksheet.addRow(['全局绑扎次数', '绑扎点位总数', '成功绑扎点位', '错绑', '成功率'])
  worksheet.addRow([
    input.totalBindCount,
    input.pointCount,
    sceneStats?.successCount ?? input.pointCount,
    sceneStats?.failureCount ?? 0,
    formatRate(sceneStats?.successCount ?? input.pointCount, input.pointCount)
  ])

  return worksheet
}

function formatRate(successCount: number, totalCount: number) {
  if (totalCount <= 0) {
    return '0.00%'
  }

  return `${((successCount / totalCount) * 100).toFixed(2)}%`
}

function upsertScenePointRecord(database: DatabaseSync, input: { pointId: number; sceneId: number; isFailed: boolean; note: string }) {
  const note = input.note.trim()

  if (!input.isFailed && note === '') {
    database.prepare('delete from scene_point_records where point_id = ? and scene_id = ?').run(input.pointId, input.sceneId)
    return
  }

  database
    .prepare(
      `
        insert into scene_point_records (point_id, scene_id, is_failed, note, updated_at)
        values (?, ?, ?, ?, ?)
        on conflict(point_id, scene_id) do update set
          is_failed = excluded.is_failed,
          note = excluded.note,
          updated_at = excluded.updated_at
      `
    )
    .run(input.pointId, input.sceneId, input.isFailed ? 1 : 0, note, getTimestamp())
}

function buildFormData(database: DatabaseSync): FormDataPayload {
  const settings = getSettings(database)
  ensurePointData(database, settings.pointCount)

  const scenes = getScenes(database)
  const records = getScenePointRecords(database, settings.pointCount)

  return {
    settings,
    scenes,
    records,
    stats: calculateFormStats(settings.pointCount, scenes, records),
    matrixMeta: mapMatrixMeta(settings)
  }
}

export function createRepository(database: DatabaseSync) {
  return {
    getFormData(): FormDataPayload {
      return buildFormData(database)
    },

    createScene(name: string): FormDataPayload {
      const normalizedName = name.trim()
      if (!normalizedName) {
        throw new RangeError('scene name is required')
      }

      database.prepare('insert into scenes (name, created_at) values (?, ?)').run(normalizedName, getTimestamp())
      return buildFormData(database)
    },

    deleteScene(sceneId: number): FormDataPayload {
      const scene = getSceneById(database, sceneId)
      const remainingSceneRow = database
        .prepare('select id from scenes where id <> ? order by id asc limit 1')
        .get(scene.id) as { id: number } | undefined

      database.exec('begin')
      try {
        database.prepare('delete from scene_point_records where scene_id = ?').run(scene.id)
        database.prepare('delete from group_save_records where scene_id = ?').run(scene.id)
        database.prepare('delete from scenes where id = ?').run(scene.id)
        database
          .prepare('update workbench_context set scene_id = ?, updated_at = ? where id = 1 and scene_id = ?')
          .run(remainingSceneRow?.id ?? null, getTimestamp(), scene.id)
        database.exec('commit')
      } catch (error) {
        database.exec('rollback')
        throw error
      }

      return buildFormData(database)
    },

    resetScene(sceneId: number): FormDataPayload {
      const scene = getSceneById(database, sceneId)
      const timestamp = getTimestamp()

      database.exec('begin')
      try {
        database.prepare('delete from scene_point_records where scene_id = ?').run(scene.id)
        database.prepare('delete from group_save_records where scene_id = ?').run(scene.id)
        database
          .prepare('update workbench_context set scene_id = ?, selected_point_id = 1, updated_at = ? where id = 1')
          .run(scene.id, timestamp)
        database.exec('commit')
      } catch (error) {
        database.exec('rollback')
        throw error
      }

      return buildFormData(database)
    },

    updatePointState(input: { pointId: number; sceneId: number; isFailed: boolean }): FormDataPayload {
      validatePointId(database, input.pointId)
      if (typeof input.isFailed !== 'boolean') {
        throw new TypeError('isFailed must be a boolean')
      }

      getSceneById(database, input.sceneId)
      const current = getScenePointRecord(database, input.pointId, input.sceneId)
      upsertScenePointRecord(database, {
        pointId: input.pointId,
        sceneId: input.sceneId,
        isFailed: input.isFailed,
        note: current?.note ?? ''
      })

      database.prepare('update points set updated_at = ? where id = ?').run(getTimestamp(), input.pointId)
      return buildFormData(database)
    },

    updatePointNote(input: { pointId: number; sceneId: number; note: string }): FormDataPayload {
      validatePointId(database, input.pointId)
      if (typeof input.note !== 'string') {
        throw new TypeError('note must be a string')
      }

      getSceneById(database, input.sceneId)
      const current = getScenePointRecord(database, input.pointId, input.sceneId)
      upsertScenePointRecord(database, {
        pointId: input.pointId,
        sceneId: input.sceneId,
        isFailed: current?.isFailed ?? false,
        note: input.note
      })

      database.prepare('update points set updated_at = ? where id = ?').run(getTimestamp(), input.pointId)
      return buildFormData(database)
    },

    updateGridDimensions(input: GridDimensionsInput): FormDataPayload {
      const nextSettings = validateGridDimensions(input)
      ensurePointData(database, nextSettings.pointCount)
      database
        .prepare(
          'update settings set point_count = ?, row_count = ?, column_count = ?, updated_at = ? where id = 1'
        )
        .run(
          nextSettings.pointCount,
          nextSettings.rowCount,
          nextSettings.columnCount,
          getTimestamp()
        )
      return buildFormData(database)
    },

    updateWorkbenchContext(input: WorkbenchContextPayload) {
      if (
        input.sceneId !== null &&
        (!Number.isInteger(input.sceneId) || input.sceneId < 1)
      ) {
        throw new RangeError('sceneId must be null or a positive integer')
      }

      if (
        input.selectedPointId !== null &&
        (!Number.isInteger(input.selectedPointId) || input.selectedPointId < 1)
      ) {
        throw new RangeError('selectedPointId must be null or a positive integer')
      }

      if (input.sceneId !== null) {
        getSceneById(database, input.sceneId)
      }

      if (input.selectedPointId !== null) {
        validatePointId(database, input.selectedPointId)
      }

      database
        .prepare(
          `
            insert into workbench_context (id, scene_id, selected_point_id, updated_at)
            values (1, ?, ?, ?)
            on conflict(id) do update set
              scene_id = excluded.scene_id,
              selected_point_id = excluded.selected_point_id,
              updated_at = excluded.updated_at
          `
        )
        .run(input.sceneId, input.selectedPointId, getTimestamp())

      return {
        ok: true
      }
    },

    saveManualGroupRecord(input: {
      sceneId: number
      selectedPointId: number
      noteOverrides?: GroupNoteOverride[]
    }): ManualGroupSaveResponse {
      validatePointId(database, input.selectedPointId)
      getSceneById(database, input.sceneId)
      const noteOverrides = normalizeNoteOverrides(input.noteOverrides)
      const groupPointIds = new Set(
        getGroupPointIdsForPoint(input.selectedPointId, getSettings(database).pointCount, getSettings(database).columnCount)
      )
      const timestamp = getTimestamp()

      database.exec('begin')
      try {
        for (const override of noteOverrides) {
          if (!groupPointIds.has(override.pointId)) {
            throw new RangeError(`pointId ${override.pointId} is not in the current group`)
          }

          const current = getScenePointRecord(database, override.pointId, input.sceneId)
          upsertScenePointRecord(database, {
            pointId: override.pointId,
            sceneId: input.sceneId,
            isFailed: current?.isFailed ?? false,
            note: override.note
          })
          updatePointTimestamp(database, override.pointId, timestamp)
        }

        const snapshot = buildGroupSnapshot(database, {
          sceneId: input.sceneId,
          selectedPointId: input.selectedPointId
        })
        const saveRecord = insertGroupSaveRecord(database, {
          sceneId: input.sceneId,
          selectedPointId: input.selectedPointId,
          groupIndex: snapshot.groupIndex,
          source: 'manual',
          rgbPath: '',
          payloadJson: JSON.stringify({
            savedAt: timestamp,
            source: 'manual',
            scene: snapshot.scene,
            selectedPointId: input.selectedPointId,
            groupIndex: snapshot.groupIndex,
            points: snapshot.points
          }),
          createdAt: timestamp
        })

        database.exec('commit')

        return {
          form: buildFormData(database),
          saveRecord
        }
      } catch (error) {
        database.exec('rollback')
        throw error
      }
    },

    saveAutoGroupRecord(input: {
      sceneId?: number
      selectedPointId?: number
      groupIndex?: number
      rgbPath: string
      detectedPoints: AutoDetectedPointPayload[]
      sourceTopic?: string
      capturedAt?: string
      rawSignal?: string
    }): AutoGroupSaveResponse {
      const context = getWorkbenchContext(database)
      const sceneId = input.sceneId ?? context?.scene_id ?? null
      const selectedPointId = input.selectedPointId ?? context?.selected_point_id ?? null

      if (!sceneId || !selectedPointId) {
        throw new RangeError('workbench context is not ready')
      }

      validatePointId(database, selectedPointId)
      const scene = getSceneById(database, sceneId)
      const snapshot = buildGroupSnapshot(database, {
        sceneId,
        selectedPointId
      })
      const timestamp = getTimestamp()
      const saveRecord = insertGroupSaveRecord(database, {
        sceneId: scene.id,
        selectedPointId: snapshot.selectedPointId,
        groupIndex: input.groupIndex ?? snapshot.groupIndex,
        source: 'ros',
        rgbPath: input.rgbPath,
        payloadJson: JSON.stringify({
          savedAt: timestamp,
          capturedAt: input.capturedAt ?? '',
          source: 'ros',
          sourceTopic: input.sourceTopic ?? '',
          rawSignal: input.rawSignal ?? '',
          scene,
          selectedPointId: snapshot.selectedPointId,
          groupIndex: input.groupIndex ?? snapshot.groupIndex,
          points: snapshot.points,
          detectedPoints: input.detectedPoints
        }),
        createdAt: timestamp
      })

      return {
        saveRecord
      }
    },

    async exportWorkbook(input: { scope: ExportScope; sceneId?: number }) {
      const settings = getSettings(database)
      const allRecords = getScenePointRecords(database, settings.pointCount)
      const totalBindCount = Number(
        (
          database
            .prepare('select count(*) as total from group_save_records')
            .get() as { total: number } | undefined
        )?.total ?? 0
      )
      const workbook = new ExcelJS.Workbook()
      workbook.creator = 'Acceptance Form Workbench'
      workbook.created = new Date()
      const usedSheetNames = new Set<string>()
      const exportTime = formatExportDisplayTime()

      if (input.scope === 'all') {
        const scenes = getScenes(database)
        if (scenes.length === 0) {
          throw new RangeError('no scenes available for export')
        }

        for (const scene of scenes) {
          await appendSceneSheet(workbook, {
            database,
            scene,
            pointCount: settings.pointCount,
            columnCount: settings.columnCount,
            allRecords,
            totalBindCount,
            exportTime,
            usedSheetNames
          })
        }
      } else {
        const scene = getSceneById(database, input.sceneId ?? 0)
        await appendSceneSheet(workbook, {
          database,
          scene,
          pointCount: settings.pointCount,
          columnCount: settings.columnCount,
          allRecords,
          totalBindCount,
          exportTime,
          usedSheetNames
        })
      }

      const output = await workbook.xlsx.writeBuffer()
      return Buffer.from(output as unknown as Uint8Array)
    }
  }
}

