import { createServer } from 'node:http'
import { execFile } from 'node:child_process'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { createReadStream, existsSync } from 'node:fs'
import path from 'node:path'
import { promisify } from 'node:util'
import { MAX_POINT_COUNT } from '../shared/constants.js'
import { parseAcceptancePlanJson } from '../shared/acceptance-plan.js'
import type {
  AutoDetectedPointPayload,
  AutoGroupSavePayload,
  ExportScope,
  GroupNoteOverride,
  ManualGroupSavePayload,
  WorkbenchContextPayload
} from '../shared/types.js'
import { closeDatabase, createDatabase } from './db.js'
import { createRepository } from './repository.js'

interface InjectRequest {
  method: 'GET' | 'PUT' | 'POST' | 'DELETE'
  path: string
  body?: unknown
}

interface AppOptions {
  databasePath: string
  staticDir?: string
  captureDir?: string
  acceptancePlanPath?: string
  acceptancePlanSshTarget?: string
  acceptancePlanLoader?: (() => Promise<string | null>) | null
}

const execFileAsync = promisify(execFile)

function jsonResponse(statusCode: number, json: unknown) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json; charset=utf-8'
    },
    body: JSON.stringify(json),
    json
  }
}

function validatePointId(value: string) {
  const pointId = Number(value)
  if (!Number.isInteger(pointId) || pointId < 1 || pointId > MAX_POINT_COUNT) {
    throw new RangeError(`pointId must be between 1 and ${MAX_POINT_COUNT}`)
  }

  return pointId
}

function validateSettingsPayload(payload: unknown) {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('settings payload must be an object')
  }

  const rowCount = Number((payload as { rowCount?: unknown }).rowCount)
  if (!Number.isInteger(rowCount) || rowCount < 1 || rowCount > MAX_POINT_COUNT) {
    throw new RangeError(`rowCount must be between 1 and ${MAX_POINT_COUNT}`)
  }

  const columnCount = Number((payload as { columnCount?: unknown }).columnCount)
  if (!Number.isInteger(columnCount) || columnCount < 1 || columnCount > MAX_POINT_COUNT) {
    throw new RangeError(`columnCount must be between 1 and ${MAX_POINT_COUNT}`)
  }

  const pointCount = rowCount * columnCount
  if (pointCount < 1 || pointCount > MAX_POINT_COUNT) {
    throw new RangeError(`pointCount must be between 1 and ${MAX_POINT_COUNT}`)
  }

  return { rowCount, columnCount }
}

function validateScenePayload(payload: unknown) {
  if (!payload || typeof payload !== 'object' || typeof (payload as { name?: unknown }).name !== 'string') {
    throw new TypeError('scene name must be a string')
  }

  return {
    name: (payload as { name: string }).name
  }
}

function validateSceneId(value: unknown) {
  const sceneId = Number(value)
  if (!Number.isInteger(sceneId) || sceneId < 1) {
    throw new RangeError('sceneId must be a positive integer')
  }

  return sceneId
}

function validateExportScope(value: unknown): ExportScope {
  return value === 'all' ? 'all' : 'scene'
}

function validateWorkbenchContextPayload(payload: unknown): WorkbenchContextPayload {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('workbench context payload must be an object')
  }

  const sceneIdRaw = (payload as { sceneId?: unknown }).sceneId
  const selectedPointIdRaw = (payload as { selectedPointId?: unknown }).selectedPointId

  const sceneId =
    sceneIdRaw === null || sceneIdRaw === undefined
      ? null
      : validateSceneId(sceneIdRaw)

  const selectedPointId =
    selectedPointIdRaw === null || selectedPointIdRaw === undefined
      ? null
      : validatePointId(String(selectedPointIdRaw))

  return {
    sceneId,
    selectedPointId
  }
}

function validateNoteOverrides(input: unknown): GroupNoteOverride[] {
  if (input === undefined) {
    return []
  }

  if (!Array.isArray(input)) {
    throw new TypeError('noteOverrides must be an array')
  }

  return input.map((item) => {
    if (!item || typeof item !== 'object') {
      throw new TypeError('noteOverrides must contain objects')
    }

    const pointId = validatePointId(String((item as { pointId?: unknown }).pointId))
    const note = (item as { note?: unknown }).note
    if (typeof note !== 'string') {
      throw new TypeError('note override note must be a string')
    }

    return {
      pointId,
      note
    }
  })
}

function validateManualGroupSavePayload(payload: unknown): ManualGroupSavePayload {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('manual group save payload must be an object')
  }

  return {
    sceneId: validateSceneId((payload as { sceneId?: unknown }).sceneId),
    selectedPointId: validatePointId(String((payload as { selectedPointId?: unknown }).selectedPointId)),
    noteOverrides: validateNoteOverrides((payload as { noteOverrides?: unknown }).noteOverrides)
  }
}

function validateDetectedPointPayload(payload: unknown): AutoDetectedPointPayload {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('detectedPoints must contain objects')
  }

  const idx = Number((payload as { idx?: unknown }).idx)
  const pixCoordRaw = (payload as { pixCoord?: unknown }).pixCoord
  const worldCoordRaw = (payload as { worldCoord?: unknown }).worldCoord
  const angle = Number((payload as { angle?: unknown }).angle)
  const isShuiguan = Boolean((payload as { isShuiguan?: unknown }).isShuiguan)

  if (!Number.isFinite(idx)) {
    throw new TypeError('detected point idx must be numeric')
  }

  if (
    !Array.isArray(pixCoordRaw) ||
    pixCoordRaw.length !== 2 ||
    pixCoordRaw.some((value) => !Number.isFinite(Number(value)))
  ) {
    throw new TypeError('detected point pixCoord must be a numeric tuple')
  }

  if (
    !Array.isArray(worldCoordRaw) ||
    worldCoordRaw.length !== 3 ||
    worldCoordRaw.some((value) => !Number.isFinite(Number(value)))
  ) {
    throw new TypeError('detected point worldCoord must be a numeric tuple')
  }

  if (!Number.isFinite(angle)) {
    throw new TypeError('detected point angle must be numeric')
  }

  return {
    idx,
    pixCoord: [Number(pixCoordRaw[0]), Number(pixCoordRaw[1])],
    worldCoord: [Number(worldCoordRaw[0]), Number(worldCoordRaw[1]), Number(worldCoordRaw[2])],
    angle,
    isShuiguan
  }
}

function validateAutoGroupSavePayload(payload: unknown): AutoGroupSavePayload {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('auto group save payload must be an object')
  }

  const rgbBase64Raw = (payload as { rgbBase64?: unknown }).rgbBase64
  const rgbBase64 = typeof rgbBase64Raw === 'string' && rgbBase64Raw.trim() ? rgbBase64Raw.trim() : undefined

  const detectedPointsRaw = (payload as { detectedPoints?: unknown }).detectedPoints
  if (!Array.isArray(detectedPointsRaw)) {
    throw new TypeError('detectedPoints must be an array')
  }

  const mimeTypeRaw = (payload as { mimeType?: unknown }).mimeType
  const mimeType = typeof mimeTypeRaw === 'string' && mimeTypeRaw.trim() ? mimeTypeRaw : undefined
  if (mimeType && !['image/jpeg', 'image/png'].includes(mimeType)) {
    throw new TypeError('mimeType must be image/jpeg or image/png')
  }

  const groupIndexRaw = (payload as { groupIndex?: unknown }).groupIndex
  const groupIndex =
    groupIndexRaw === undefined || groupIndexRaw === null
      ? undefined
      : validateSceneId(groupIndexRaw)

  const sceneIdRaw = (payload as { sceneId?: unknown }).sceneId
  const selectedPointIdRaw = (payload as { selectedPointId?: unknown }).selectedPointId
  const sceneId =
    sceneIdRaw === undefined || sceneIdRaw === null
      ? undefined
      : validateSceneId(sceneIdRaw)
  const selectedPointId =
    selectedPointIdRaw === undefined || selectedPointIdRaw === null
      ? undefined
      : validatePointId(String(selectedPointIdRaw))

  return {
    sceneId,
    selectedPointId,
    groupIndex,
    sourceTopic:
      typeof (payload as { sourceTopic?: unknown }).sourceTopic === 'string'
        ? (payload as { sourceTopic: string }).sourceTopic
        : undefined,
    rawSignal:
      typeof (payload as { rawSignal?: unknown }).rawSignal === 'string'
        ? (payload as { rawSignal: string }).rawSignal
        : undefined,
    capturedAt:
      typeof (payload as { capturedAt?: unknown }).capturedAt === 'string'
        ? (payload as { capturedAt: string }).capturedAt
        : undefined,
    mimeType,
    rgbBase64,
    detectedPoints: detectedPointsRaw.map((item) => validateDetectedPointPayload(item))
  }
}

function validateStatePayload(payload: unknown) {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('state payload must be an object')
  }

  const sceneId = validateSceneId((payload as { sceneId?: unknown }).sceneId)
  const isFailed = (payload as { isFailed?: unknown }).isFailed

  if (typeof isFailed !== 'boolean') {
    throw new TypeError('isFailed must be a boolean')
  }

  return { sceneId, isFailed }
}

function validateNotePayload(payload: unknown) {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('note payload must be an object')
  }

  const sceneId = validateSceneId((payload as { sceneId?: unknown }).sceneId)
  const note = (payload as { note?: unknown }).note

  if (typeof note !== 'string') {
    throw new TypeError('note must be a string')
  }

  return { sceneId, note }
}

function getContentType(filePath: string) {
  if (filePath.endsWith('.html')) return 'text/html; charset=utf-8'
  if (filePath.endsWith('.js')) return 'application/javascript; charset=utf-8'
  if (filePath.endsWith('.css')) return 'text/css; charset=utf-8'
  if (filePath.endsWith('.svg')) return 'image/svg+xml'
  return 'application/octet-stream'
}

function inferImageExtension(mimeType: string) {
  return mimeType === 'image/png' ? 'png' : 'jpg'
}

function padTimePart(value: number, width = 2) {
  return String(value).padStart(width, '0')
}

function createExportTimestamp(date = new Date()) {
  return [
    date.getFullYear(),
    padTimePart(date.getMonth() + 1),
    padTimePart(date.getDate())
  ].join('') +
    '-' +
    [
      padTimePart(date.getHours()),
      padTimePart(date.getMinutes()),
      padTimePart(date.getSeconds())
    ].join('')
}

export function createApp(options: AppOptions) {
  const database = createDatabase(options.databasePath)
  const repository = createRepository(database)

  async function loadAcceptancePlan() {
    const sourcePayload =
      options.acceptancePlanLoader
        ? await options.acceptancePlanLoader()
        : await (async () => {
            const acceptancePlanPath = options.acceptancePlanPath?.trim()
            if (!acceptancePlanPath) {
              return null
            }

            if (existsSync(acceptancePlanPath)) {
              return readFile(acceptancePlanPath, 'utf8')
            }

            const sshTarget = options.acceptancePlanSshTarget?.trim()
            if (!sshTarget) {
              return null
            }

            const { stdout } = await execFileAsync(
              'ssh',
              [
                '-o',
                'BatchMode=yes',
                '-o',
                'ConnectTimeout=5',
                sshTarget,
                'cat',
                acceptancePlanPath
              ],
              {
                maxBuffer: 16 * 1024 * 1024
              }
            )

            return stdout
          })()

    return parseAcceptancePlanJson(sourcePayload ?? '')
  }

  async function persistCaptureImage(payload: AutoGroupSavePayload) {
    if (!payload.rgbBase64) {
      return ''
    }

    if (!options.captureDir) {
      throw new Error('captureDir is not configured')
    }

    await mkdir(options.captureDir, { recursive: true })
    const extension = inferImageExtension(payload.mimeType ?? 'image/jpeg')
    const fileName = `capture-${Date.now()}-${Math.random().toString(16).slice(2, 8)}.${extension}`
    const filePath = path.join(options.captureDir, fileName)
    await writeFile(filePath, Buffer.from(payload.rgbBase64, 'base64'))
    return filePath
  }

  async function handleApiRequest(request: InjectRequest) {
    const url = new URL(request.path, 'http://127.0.0.1')

    try {
      if (request.method === 'GET' && url.pathname === '/api/acceptance-plan') {
        return jsonResponse(200, {
          plan: await loadAcceptancePlan()
        })
      }

      if (request.method === 'GET' && url.pathname === '/api/form') {
        return jsonResponse(200, repository.getFormData())
      }

      if (request.method === 'PUT' && url.pathname === '/api/workbench-context') {
        const payload = validateWorkbenchContextPayload(request.body)
        return jsonResponse(200, repository.updateWorkbenchContext(payload))
      }

      if (request.method === 'POST' && url.pathname === '/api/scenes') {
        const payload = validateScenePayload(request.body)
        return jsonResponse(200, repository.createScene(payload.name))
      }

      const sceneResetMatch = url.pathname.match(/^\/api\/scenes\/(\d+)\/reset$/)
      if (request.method === 'POST' && sceneResetMatch) {
        const sceneId = validateSceneId(sceneResetMatch[1])
        return jsonResponse(200, repository.resetScene(sceneId))
      }

      const sceneDeleteMatch = url.pathname.match(/^\/api\/scenes\/(\d+)$/)
      if (request.method === 'DELETE' && sceneDeleteMatch) {
        const sceneId = validateSceneId(sceneDeleteMatch[1])
        return jsonResponse(200, repository.deleteScene(sceneId))
      }

      if (request.method === 'POST' && url.pathname === '/api/group-save/manual') {
        const payload = validateManualGroupSavePayload(request.body)
        return jsonResponse(200, repository.saveManualGroupRecord(payload))
      }

      if (request.method === 'POST' && url.pathname === '/api/group-save/auto') {
        const payload = validateAutoGroupSavePayload(request.body)
        const rgbPath = await persistCaptureImage(payload)
        return jsonResponse(
          200,
          repository.saveAutoGroupRecord({
            sceneId: payload.sceneId,
            selectedPointId: payload.selectedPointId,
            groupIndex: payload.groupIndex,
            rgbPath,
            detectedPoints: payload.detectedPoints,
            sourceTopic: payload.sourceTopic,
            capturedAt: payload.capturedAt,
            rawSignal: payload.rawSignal
          })
        )
      }

      if (request.method === 'GET' && url.pathname === '/api/export.xlsx') {
        const scope = validateExportScope(url.searchParams.get('scope'))
        const sceneId = scope === 'scene' ? validateSceneId(url.searchParams.get('sceneId')) : undefined
        const buffer = await repository.exportWorkbook({ scope, sceneId })
        const exportTimestamp = createExportTimestamp()
        return {
          statusCode: 200,
          headers: {
            'content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'content-disposition': `attachment; filename="${exportTimestamp}.xlsx"`
          },
          body: buffer,
          json: null
        }
      }

      const pointStateMatch = url.pathname.match(/^\/api\/points\/(\d+)\/state$/)
      if (request.method === 'PUT' && pointStateMatch) {
        const pointId = validatePointId(pointStateMatch[1]!)
        const payload = validateStatePayload(request.body)
        return jsonResponse(200, repository.updatePointState({ pointId, ...payload }))
      }

      const pointNoteMatch = url.pathname.match(/^\/api\/points\/(\d+)\/note$/)
      if (request.method === 'PUT' && pointNoteMatch) {
        const pointId = validatePointId(pointNoteMatch[1]!)
        const payload = validateNotePayload(request.body)
        return jsonResponse(200, repository.updatePointNote({ pointId, ...payload }))
      }

      if (request.method === 'PUT' && url.pathname === '/api/settings') {
        const payload = validateSettingsPayload(request.body)
        return jsonResponse(200, repository.updateGridDimensions(payload))
      }

      return jsonResponse(404, { message: 'Not Found' })
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error'
      return jsonResponse(400, { message })
    }
  }

  const server = createServer(async (req, res) => {
    const method =
      req.method === 'POST'
        ? 'POST'
        : req.method === 'PUT'
          ? 'PUT'
          : req.method === 'DELETE'
            ? 'DELETE'
            : 'GET'
    const requestPath = req.url ?? '/'

    if (requestPath.startsWith('/api/')) {
      let body: unknown = undefined
      if (method === 'PUT' || method === 'POST') {
        const chunks: Buffer[] = []
        for await (const chunk of req) {
          chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
        }
        body = chunks.length > 0 ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : undefined
      }

      const response = await handleApiRequest({
        method,
        path: requestPath,
        body
      })

      res.writeHead(response.statusCode, response.headers)
      res.end(response.body)
      return
    }

    const staticDir = options.staticDir
    if (!staticDir) {
      res.writeHead(404)
      res.end('Not Found')
      return
    }

    const pathname = new URL(requestPath, 'http://127.0.0.1').pathname
    const relativePath = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '')
    const targetFile = path.join(staticDir, relativePath)
    if (!existsSync(targetFile)) {
      res.writeHead(404)
      res.end('Not Found')
      return
    }

    res.writeHead(200, { 'content-type': getContentType(targetFile) })
    createReadStream(targetFile).pipe(res)
  })

  return {
    server,
    async inject(request: InjectRequest) {
      return handleApiRequest(request)
    },
    async readStatic(filePath: string) {
      if (!options.staticDir) {
        return ''
      }
      return readFile(path.join(options.staticDir, filePath), 'utf8')
    },
    close() {
      server.close()
      closeDatabase(database)
    }
  }
}

