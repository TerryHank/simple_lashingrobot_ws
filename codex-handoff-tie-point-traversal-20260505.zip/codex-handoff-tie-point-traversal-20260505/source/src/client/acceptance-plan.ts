import { onScopeDispose, ref, watch } from 'vue'
import { subscribeToRosTopic, useRosBridgeConnection } from './ros-bridge.js'
import { parseAcceptancePlanJson } from '../shared/acceptance-plan.js'
import { extractRosStringData, type RosStringMessage } from '../shared/ros-messages.js'
import type { AcceptancePlanPayload } from '../shared/types.js'

const ROS_ACCEPTANCE_PLAN_TOPIC = '/acceptance/plan'
const ROS_ACCEPTANCE_PLAN_MESSAGE_TYPE = 'std_msgs/String'

export function useAcceptancePlan(topicName = ROS_ACCEPTANCE_PLAN_TOPIC) {
  const { status: rosStatus } = useRosBridgeConnection()
  const state = ref<AcceptancePlanPayload | null>(null)
  const hasReceivedMessage = ref(false)

  let subscriptionVersion = 0
  let releaseSubscription: null | (() => void) = null

  function stopSubscription() {
    if (!releaseSubscription) {
      return
    }

    releaseSubscription()
    releaseSubscription = null
  }

  function resetState() {
    state.value = null
    hasReceivedMessage.value = false
  }

  async function bindSubscription() {
    subscriptionVersion += 1
    const activeVersion = subscriptionVersion

    stopSubscription()
    if (rosStatus.value !== 'connected') {
      resetState()
      return
    }

    try {
      const unsubscribe = await subscribeToRosTopic<RosStringMessage>({
        topicName,
        messageType: ROS_ACCEPTANCE_PLAN_MESSAGE_TYPE,
        onMessage: (message) => {
          if (activeVersion !== subscriptionVersion) {
            return
          }

          const parsed = parseAcceptancePlanJson(extractRosStringData(message))
          if (!parsed) {
            return
          }

          state.value = parsed
          hasReceivedMessage.value = true
        }
      })

      if (activeVersion !== subscriptionVersion) {
        unsubscribe()
        return
      }

      releaseSubscription = unsubscribe
    } catch {
      resetState()
    }
  }

  watch(rosStatus, () => {
    void bindSubscription()
  }, { immediate: true })

  onScopeDispose(() => {
    subscriptionVersion += 1
    stopSubscription()
  })

  return {
    state,
    hasReceivedMessage
  }
}
