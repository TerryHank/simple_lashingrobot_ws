import { computed, ref } from 'vue'
import { DEFAULT_POINT_COUNT, GRID_COLUMNS, GRID_ROWS, GROUP_SIZE } from '../shared/constants.js'
import {
  formatAxisValue,
  getGroupPointIds,
  getGroupCount,
  getGroupIndex,
  getGroupNavigationPointId,
  getGroupPointIdsForPoint,
  getExactGridDimensions,
  getPointCountFromGrid,
  getPointCoordinate
} from '../shared/matrix.js'
import { formatDisplayPointTag } from '../shared/point-display.js'
import { getScenePointState } from '../shared/progress.js'
import type {
  AcceptancePlanPayload,
  ExportScope,
  FormDataPayload,
  FormSettings,
  FormStats,
  GroupNoteOverride,
  GridDimensionsInput,
  MatrixMeta,
  Scene,
  SceneStat,
  ScenePointRecord,
  ScenePointState,
  GroupSaveSummary
} from '../shared/types.js'
import * as api from './api.js'

const LAST_POINT_STORAGE_KEY = 'acceptance-form:last-point'

export type SaveState = 'idle' | 'saving' | 'saved' | 'error'

type ApiClient = typeof api

function createDefaultSettings(pointCount = DEFAULT_POINT_COUNT): FormSettings {
  if (pointCount === DEFAULT_POINT_COUNT) {
    return {
      pointCount,
      columnCount: GRID_COLUMNS,
      rowCount: GRID_ROWS,
      groupSize: GROUP_SIZE
    }
  }

  const { columnCount, rowCount } = getExactGridDimensions(pointCount)
  return {
    pointCount,
    columnCount,
    rowCount,
    groupSize: GROUP_SIZE
  }
}

function createSettingsFromGrid(input: GridDimensionsInput): FormSettings {
  return {
    pointCount: getPointCountFromGrid(input.rowCount, input.columnCount),
    rowCount: input.rowCount,
    columnCount: input.columnCount,
    groupSize: GROUP_SIZE
  }
}

function createDefaultStats(pointCount = DEFAULT_POINT_COUNT): FormStats {
  return {
    totalPoints: pointCount,
    totalScenes: 0,
    sceneStats: []
  }
}

function createDefaultPointState(): ScenePointState {
  return {
    isFailed: false,
    hasRecord: false,
    note: '',
    updatedAt: ''
  }
}

export function createInitialSelection(previous?: number, maxPointCount = DEFAULT_POINT_COUNT) {
  if (typeof previous !== 'number' || !Number.isInteger(previous)) {
    return 1
  }

  if (previous < 1 || previous > maxPointCount) {
    return 1
  }

  return previous
}

function readStoredSelection() {
  if (typeof window === 'undefined') {
    return undefined
  }

  const raw = window.localStorage.getItem(LAST_POINT_STORAGE_KEY)
  return raw ? Number(raw) : undefined
}

function storeSelection(pointId: number) {
  if (typeof window === 'undefined') {
    return
  }

  window.localStorage.setItem(LAST_POINT_STORAGE_KEY, String(pointId))
}

function recordKey(pointId: number, sceneId: number) {
  return `${pointId}:${sceneId}`
}

function buildRecordMap(records: ScenePointRecord[]) {
  return new Map(records.map((record) => [recordKey(record.pointId, record.sceneId), record]))
}

function createPlanStats(
  plan: AcceptancePlanPayload,
  sceneId: number,
  sceneName: string,
  recordMap: Map<string, ScenePointRecord>
): SceneStat {
  let recordedCount = 0
  let failureCount = 0
  let notedCount = 0

  for (const point of plan.points) {
    const state = getScenePointState(point.pointId, sceneId, recordMap)
    if (state.hasRecord) {
      recordedCount += 1
    }
    if (state.isFailed) {
      failureCount += 1
    }
    if (state.note.trim()) {
      notedCount += 1
    }
  }

  const recordedSuccessCount = recordedCount - failureCount
  const defaultSuccessCount = Math.max(0, plan.pointCount - recordedCount)

  return {
    sceneId,
    sceneName,
    recordedCount,
    recordedSuccessCount,
    defaultSuccessCount,
    failureCount,
    successCount: Math.max(0, plan.pointCount - failureCount),
    notedCount
  }
}

function formatWorldCoordinateValue(value: number) {
  const rounded = Number(value.toFixed(3))
  return Number.isInteger(rounded) ? String(rounded) : String(rounded)
}

function formatWorldCoordinateLabel(worldCoord: [number, number, number]) {
  return worldCoord.map((value) => formatWorldCoordinateValue(value)).join(', ')
}

function normalizeFormSettings(form: FormDataPayload) {
  const matrixMeta = form.matrixMeta ?? createSettingsFromGrid({
    rowCount: form.settings.rowCount,
    columnCount: form.settings.columnCount
  })
  return {
    pointCount:
      form.settings.pointCount ??
      getPointCountFromGrid(form.settings.rowCount, form.settings.columnCount),
    columnCount: form.settings.columnCount ?? matrixMeta.columnCount,
    rowCount: form.settings.rowCount ?? matrixMeta.rowCount,
    groupSize: form.settings.groupSize ?? matrixMeta.groupSize
  }
}

export function createAcceptanceStore(client: ApiClient = api) {
  const initialized = ref(false)
  const loading = ref(true)
  const errorMessage = ref('')
  const saveState = ref<SaveState>('idle')
  const settings = ref<FormSettings>(createDefaultSettings())
  const scenes = ref<Scene[]>([])
  const stats = ref<FormStats>(createDefaultStats())
  const recordMap = ref<Map<string, ScenePointRecord>>(new Map())
  const selectedPointId = ref(1)
  const activeSceneId = ref<number | null>(null)
  const hoveredPointId = ref<number | null>(null)
  const acceptancePlan = ref<AcceptancePlanPayload | null>(null)

  const planPoints = computed(() => acceptancePlan.value?.points ?? [])
  const planAreas = computed(() => acceptancePlan.value?.areas ?? [])
  const planPointMap = computed(() => new Map(planPoints.value.map((point) => [point.pointId, point])))
  const planAreaMap = computed(() => new Map(planAreas.value.map((area) => [area.areaIndex, area])))
  const planAreaIndexByPointId = computed(() => {
    const areaIndexByPointId = new Map<number, number>()
    for (const area of planAreas.value) {
      for (const pointId of area.pointIds) {
        areaIndexByPointId.set(pointId, area.areaIndex)
      }
    }
    return areaIndexByPointId
  })
  const activePointIdSet = computed(() =>
    acceptancePlan.value ? new Set(planPoints.value.map((point) => point.pointId)) : null
  )
  const currentPlanAreaIndex = computed(() =>
    acceptancePlan.value ? planAreaIndexByPointId.value.get(selectedPointId.value) ?? null : null
  )
  const currentPlanArea = computed(() =>
    currentPlanAreaIndex.value === null ? null : planAreaMap.value.get(currentPlanAreaIndex.value) ?? null
  )
  const currentPlanAreaOrdinal = computed(() =>
    currentPlanArea.value
      ? planAreas.value.findIndex((area) => area.areaIndex === currentPlanArea.value?.areaIndex) + 1
      : null
  )

  const matrixMeta = computed<MatrixMeta>(() => ({
    pointCount: acceptancePlan.value?.pointCount ?? settings.value.pointCount,
    columnCount: acceptancePlan.value?.columnCount ?? settings.value.columnCount,
    rowCount: acceptancePlan.value?.rowCount ?? settings.value.rowCount,
    groupSize: settings.value.groupSize
  }))
  const activeScene = computed(() => scenes.value.find((scene) => scene.id === activeSceneId.value) ?? null)
  const activeSceneStats = computed(
    () => {
      if (!activeSceneId.value) {
        return null
      }

      const scene = scenes.value.find((item) => item.id === activeSceneId.value) ?? null
      if (!scene) {
        return null
      }

      if (acceptancePlan.value) {
        return createPlanStats(acceptancePlan.value, scene.id, scene.name, recordMap.value)
      }

      return stats.value.sceneStats.find((item) => item.sceneId === activeSceneId.value) ?? null
    }
  )
  const currentGroupIndex = computed(() => {
    if (acceptancePlan.value) {
      return currentPlanArea.value?.areaIndex ?? planAreas.value[0]?.areaIndex ?? 1
    }

    return getGroupIndex(selectedPointId.value, settings.value.pointCount, settings.value.columnCount)
  })
  const planGroupCount = computed(() =>
    planAreas.value.reduce((maxAreaIndex, area) => Math.max(maxAreaIndex, area.areaIndex), 0)
  )
  const groupCount = computed(() =>
    acceptancePlan.value
      ? Math.max(planGroupCount.value, 1)
      : getGroupCount(settings.value.pointCount, settings.value.columnCount)
  )
  const currentGroupPointIds = computed(() => {
    if (acceptancePlan.value) {
      return currentPlanArea.value?.pointIds ?? []
    }

    return getGroupPointIdsForPoint(selectedPointId.value, settings.value.pointCount, settings.value.columnCount)
  })

  function getPointCoordinateLabel(pointId: number) {
    const plannedPoint = planPointMap.value.get(pointId)
    if (plannedPoint) {
      return {
        x: plannedPoint.x,
        y: plannedPoint.y,
        coordinateLabel: `${formatAxisValue(plannedPoint.x)},${formatAxisValue(plannedPoint.y)}`,
        worldCoordinateLabel: formatWorldCoordinateLabel(plannedPoint.worldCoord)
      }
    }

    const coordinate = getPointCoordinate(
      pointId,
      settings.value.pointCount,
      settings.value.columnCount
    )
    return {
      x: coordinate.x,
      y: coordinate.y,
      coordinateLabel: `${formatAxisValue(coordinate.x)},${formatAxisValue(coordinate.y)}`,
      worldCoordinateLabel: null
    }
  }

  function getPointState(pointId: number, sceneId = activeSceneId.value) {
    if (!sceneId) {
      return createDefaultPointState()
    }

    return getScenePointState(pointId, sceneId, recordMap.value)
  }

  const currentGroupPoints = computed(() =>
    currentGroupPointIds.value
      .map((pointId) => {
        const coordinate = getPointCoordinateLabel(pointId)
        const state = getPointState(pointId)

        return {
          pointId,
          coordinate: {
            x: coordinate.x,
            y: coordinate.y
          },
          coordinateLabel: coordinate.coordinateLabel,
          worldCoordinateLabel: coordinate.worldCoordinateLabel,
          ...state
        }
      })
      .sort((left, right) => {
        if (left.coordinate.y !== right.coordinate.y) {
          return right.coordinate.y - left.coordinate.y
        }

        return left.coordinate.x - right.coordinate.x
      })
  )

  const gridPoints = computed(() => {
    const currentGroupSet = new Set(currentGroupPointIds.value)
    const pointIds = acceptancePlan.value
      ? planPoints.value.map((point) => point.pointId)
      : Array.from({ length: settings.value.pointCount }, (_, index) => index + 1)

    return pointIds.map((pointId) => {
      const coordinate = getPointCoordinateLabel(pointId)
      const state = getPointState(pointId)
      const hoverParts = [
        `点位 ${formatDisplayPointTag(pointId)}`,
        `坐标 ${coordinate.coordinateLabel}`,
        coordinate.worldCoordinateLabel ? `世界 ${coordinate.worldCoordinateLabel}` : null,
        state.note ? `备注 ${state.note}` : '无备注'
      ].filter((part): part is string => Boolean(part))

      return {
        pointId,
        x: coordinate.x,
        y: coordinate.y,
        coordinateLabel: coordinate.coordinateLabel,
        worldCoordinateLabel: coordinate.worldCoordinateLabel,
        isFailed: state.isFailed,
        hasRecord: state.hasRecord,
        note: state.note,
        updatedAt: state.updatedAt,
        isCurrent: pointId === selectedPointId.value,
        isInCurrentGroup: currentGroupSet.has(pointId),
        hoverLabel: hoverParts.join(' · ')
      }
    })
  })

  const hoveredPoint = computed(() =>
    hoveredPointId.value === null ? null : gridPoints.value.find((point) => point.pointId === hoveredPointId.value) ?? null
  )
  const canExport = computed(() => scenes.value.length > 0)

  function getPlanFallbackPointId() {
    return acceptancePlan.value?.areas[0]?.pointIds[0] ?? acceptancePlan.value?.points[0]?.pointId ?? 1
  }

  function normalizeSelectedPointId(pointId: number, maxPointCount = settings.value.pointCount) {
    if (acceptancePlan.value) {
      return activePointIdSet.value?.has(pointId) ? pointId : getPlanFallbackPointId()
    }

    return createInitialSelection(pointId, maxPointCount)
  }

  function applyFormData(form: FormDataPayload) {
    settings.value = normalizeFormSettings(form)
    scenes.value = form.scenes
    stats.value = form.stats
    recordMap.value = buildRecordMap(form.records)

    if (form.scenes.length === 0) {
      activeSceneId.value = null
      return
    }

    if (!form.scenes.some((scene) => scene.id === activeSceneId.value)) {
      activeSceneId.value = form.scenes[0]?.id ?? null
    }
  }

  async function syncWorkbenchContext() {
    if (!initialized.value) {
      return
    }

    try {
      await client.updateWorkbenchContext({
        sceneId: activeSceneId.value,
        selectedPointId: selectedPointId.value
      })
    } catch (error) {
      errorMessage.value = error instanceof Error ? error.message : '工作台上下文同步失败'
    }
  }

  async function load() {
    loading.value = true
    errorMessage.value = ''

    try {
      const form = await client.fetchFormData()
      applyFormData(form)
      const initialSelection = createInitialSelection(
        readStoredSelection(),
        Math.max(form.settings.pointCount, acceptancePlan.value?.maxPointId ?? form.settings.pointCount)
      )
      selectedPointId.value = normalizeSelectedPointId(initialSelection, form.settings.pointCount)
      storeSelection(selectedPointId.value)
      initialized.value = true
      await syncWorkbenchContext()
    } catch (error) {
      errorMessage.value = error instanceof Error ? error.message : '加载失败'
    } finally {
      loading.value = false
    }
  }

  async function goToPoint(pointId: number) {
    const isSelectable =
      acceptancePlan.value
        ? activePointIdSet.value?.has(pointId) ?? false
        : pointId >= 1 && pointId <= settings.value.pointCount

    if (!isSelectable) {
      return
    }

    selectedPointId.value = pointId
    storeSelection(pointId)
    await syncWorkbenchContext()
  }

  async function goToGroup(groupIndex: number) {
    if (acceptancePlan.value) {
      const targetArea = planAreaMap.value.get(groupIndex) ?? null
      const targetPointId = targetArea?.pointIds[0] ?? null
      if (targetPointId === null) {
        return
      }

      await goToPoint(targetPointId)
      return
    }

    const clampedGroupIndex = Math.max(1, Math.min(groupCount.value, groupIndex))
    const targetPointId = getGroupNavigationPointId(
      clampedGroupIndex,
      settings.value.pointCount,
      settings.value.columnCount
    )
    await goToPoint(targetPointId)
  }

  async function moveGroup(offset: number) {
    if (acceptancePlan.value) {
      const currentOrdinal = currentPlanAreaOrdinal.value ?? 1
      const targetOrdinal = Math.max(1, Math.min(planAreas.value.length, currentOrdinal + offset))
      const targetArea = planAreas.value[targetOrdinal - 1] ?? null
      if (!targetArea) {
        return
      }

      await goToPoint(targetArea.pointIds[0] ?? selectedPointId.value)
      return
    }

    await goToGroup(currentGroupIndex.value + offset)
  }

  async function saveCurrentGroup(noteOverrides: GroupNoteOverride[] = []) {
    if (!activeSceneId.value) {
      return null
    }

    if (acceptancePlan.value) {
      saveState.value = 'saving'
      errorMessage.value = ''

      try {
        let nextForm: FormDataPayload | null = null

        for (const override of noteOverrides) {
          nextForm = await client.updatePointNote({
            pointId: override.pointId,
            sceneId: activeSceneId.value,
            note: override.note
          })
        }

        if (nextForm) {
          applyFormData(nextForm)
        }

        saveState.value = 'saved'
        await syncWorkbenchContext()
        return {
          id: 0,
          sceneId: activeSceneId.value,
          selectedPointId: selectedPointId.value,
          groupIndex: currentGroupIndex.value,
          source: 'manual',
          rgbPath: '',
          createdAt: new Date().toISOString()
        } satisfies GroupSaveSummary
      } catch (error) {
        saveState.value = 'error'
        errorMessage.value = error instanceof Error ? error.message : '分组保存失败'
        return null
      }
    }

    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const response = await client.saveCurrentGroup({
        sceneId: activeSceneId.value,
        selectedPointId: selectedPointId.value,
        noteOverrides
      })
      applyFormData(response.form)
      saveState.value = 'saved'
      await syncWorkbenchContext()
      return response.saveRecord
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : '分组保存失败'
      return null
    }
  }

  async function saveCurrentGroupAndMoveNext(noteOverrides: GroupNoteOverride[] = []) {
    const saved = await saveCurrentGroup(noteOverrides)

    if (!saved) {
      return null
    }

    if (acceptancePlan.value) {
      const nextOrdinal = Math.min(planAreas.value.length, (currentPlanAreaOrdinal.value ?? 1) + 1)
      const targetArea = planAreas.value[nextOrdinal - 1] ?? currentPlanArea.value ?? null
      if (targetArea?.pointIds[0]) {
        await goToPoint(targetArea.pointIds[0])
      }
      return saved
    }

    const nextGroupIndex = Math.min(groupCount.value, currentGroupIndex.value + 1)
    await goToGroup(nextGroupIndex)
    return saved
  }

  async function togglePointFailed(pointId = selectedPointId.value) {
    if (!activeSceneId.value) {
      return
    }

    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const current = getPointState(pointId, activeSceneId.value)
      const form = await client.updatePointState({
        pointId,
        sceneId: activeSceneId.value,
        isFailed: !current.isFailed
      })
      applyFormData(form)
      selectedPointId.value = normalizeSelectedPointId(pointId, form.settings.pointCount)
      storeSelection(selectedPointId.value)
      saveState.value = 'saved'
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : '保存失败'
    }
  }

  async function savePointNote(pointId: number, note: string) {
    if (!activeSceneId.value) {
      return
    }

    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const form = await client.updatePointNote({
        pointId,
        sceneId: activeSceneId.value,
        note
      })
      applyFormData(form)
      saveState.value = 'saved'
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : '备注保存失败'
    }
  }

  async function createScene(name: string) {
    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const form = await client.createScene(name)
      applyFormData(form)
      activeSceneId.value = form.scenes.at(-1)?.id ?? null
      saveState.value = 'saved'
      await syncWorkbenchContext()
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : '新增场景失败'
    }
  }

  async function deleteScene(sceneId: number) {
    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const form = await client.deleteScene(sceneId)
      applyFormData(form)
      if (form.scenes.length === 0) {
        activeSceneId.value = null
      }
      saveState.value = 'saved'
      await syncWorkbenchContext()
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : '删除场景失败'
    }
  }

  async function resetScene(sceneId: number) {
    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const form = await client.resetScene(sceneId)
      applyFormData(form)
      activeSceneId.value = form.scenes.some((scene) => scene.id === sceneId) ? sceneId : form.scenes[0]?.id ?? null
      selectedPointId.value = 1
      hoveredPointId.value = null
      storeSelection(selectedPointId.value)
      saveState.value = 'saved'
      await syncWorkbenchContext()
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : '恢复默认状态失败'
    }
  }

  async function selectScene(sceneId: number) {
    activeSceneId.value = sceneId
    await syncWorkbenchContext()
  }

  async function applyAcceptancePlan(plan: AcceptancePlanPayload | null) {
    acceptancePlan.value = plan

    if (!plan) {
      selectedPointId.value = normalizeSelectedPointId(selectedPointId.value, settings.value.pointCount)
      storeSelection(selectedPointId.value)
      await syncWorkbenchContext()
      return
    }

    selectedPointId.value = normalizeSelectedPointId(selectedPointId.value, plan.maxPointId)
    hoveredPointId.value = null

    storeSelection(selectedPointId.value)
    await syncWorkbenchContext()
  }

  function getGroupIndexForPoint(pointId: number) {
    if (acceptancePlan.value) {
      return planAreaIndexByPointId.value.get(pointId) ?? null
    }

    return getGroupIndex(pointId, settings.value.pointCount, settings.value.columnCount)
  }

  function getPointIdsForGroup(groupIndex: number) {
    if (acceptancePlan.value) {
      return planAreaMap.value.get(groupIndex)?.pointIds ?? []
    }

    return getGroupPointIds(groupIndex, settings.value.pointCount, settings.value.columnCount)
  }

  function resolveExternalGroupIndex(groupIndex: number | null, allDone = false) {
    if (acceptancePlan.value) {
      if (allDone) {
        return planAreas.value.at(-1)?.areaIndex ?? null
      }

      if (groupIndex === null) {
        return null
      }

      return planAreaMap.value.has(groupIndex) ? groupIndex : null
    }

    if (allDone) {
      return groupCount.value
    }

    if (!Number.isInteger(groupIndex) || groupIndex === null) {
      return null
    }

    return groupIndex >= 1 && groupIndex <= groupCount.value ? groupIndex : null
  }

  async function saveGroupFromRos(input: {
    groupIndex: number
    sourceTopic?: string
    rawSignal?: string
    capturedAt?: string
    mimeType?: string
    rgbBase64?: string
    detectedPoints: Parameters<typeof client.saveAutoGroup>[0]['detectedPoints']
  }) {
    if (!activeSceneId.value) {
      return null
    }

    const selectedPointIdForSave = getPointIdsForGroup(input.groupIndex)[0] ?? null
    if (selectedPointIdForSave === null) {
      return null
    }

    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const response = await client.saveAutoGroup({
        sceneId: activeSceneId.value,
        selectedPointId: selectedPointIdForSave,
        groupIndex: input.groupIndex,
        sourceTopic: input.sourceTopic,
        rawSignal: input.rawSignal,
        capturedAt: input.capturedAt,
        mimeType: input.mimeType,
        rgbBase64: input.rgbBase64,
        detectedPoints: input.detectedPoints
      })
      saveState.value = 'saved'
      return response.saveRecord
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : 'ROS 自动保存失败'
      return null
    }
  }

  async function updateGridDimensions(input: GridDimensionsInput) {
    saveState.value = 'saving'
    errorMessage.value = ''

    try {
      const form = await client.updateSettings(input)
      applyFormData(form)
      selectedPointId.value = normalizeSelectedPointId(selectedPointId.value, form.settings.pointCount)
      storeSelection(selectedPointId.value)
      saveState.value = 'saved'
      await syncWorkbenchContext()
    } catch (error) {
      saveState.value = 'error'
      errorMessage.value = error instanceof Error ? error.message : '更新矩阵尺寸失败'
    }
  }

  function setHoveredPoint(pointId: number | null) {
    hoveredPointId.value = pointId
  }

  function exportExcel(scope: ExportScope = 'scene') {
    if (typeof window === 'undefined') {
      return
    }

    if (scope === 'all') {
      if (scenes.value.length === 0) {
        return
      }

      window.open('/api/export.xlsx?scope=all', '_blank')
      return
    }

    if (!activeSceneId.value) {
      return
    }

    window.open(`/api/export.xlsx?scope=scene&sceneId=${activeSceneId.value}`, '_blank')
  }

  return {
    initialized,
    loading,
    errorMessage,
    saveState,
    settings,
    scenes,
    stats,
    selectedPointId,
    activeSceneId,
    activeScene,
    activeSceneStats,
    matrixMeta,
    currentGroupIndex,
    groupCount,
    currentGroupPoints,
    gridPoints,
    hoveredPointId,
    hoveredPoint,
    canExport,
    acceptancePlan,
    applyFormData,
    applyAcceptancePlan,
    load,
    goToPoint,
    goToGroup,
    moveGroup,
    saveCurrentGroup,
    saveCurrentGroupAndMoveNext,
    saveGroupFromRos,
    selectScene,
    createScene,
    deleteScene,
    resetScene,
    updateGridDimensions,
    togglePointFailed,
    savePointNote,
    setHoveredPoint,
    getPointState,
    getGroupIndexForPoint,
    getPointIdsForGroup,
    resolveExternalGroupIndex,
    exportExcel
  }
}

