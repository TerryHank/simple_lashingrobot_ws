import { onScopeDispose, ref, watch } from 'vue'
import { subscribeToRosTopic, useRosBridgeConnection } from './ros-bridge.js'
import {
  normalizeAreaProgress,
  type RosAreaProgressMessage
} from '../shared/ros-messages.js'

const ROS_AREA_PROGRESS_TOPIC = '/cabin/area_progress'
const ROS_AREA_PROGRESS_MESSAGE_TYPE = 'chassis_ctrl/AreaProgress'
const JUST_FINISHED_PULSE_DURATION_MS = 1200

export type AreaProgressState = {
  currentAreaIndex: number | null
  totalAreaCount: number | null
  justFinishedAreaIndex: number | null
  readyForNextArea: boolean
  allDone: boolean
}

export type AreaProgressUpdate = {
  state: AreaProgressState
  shouldPulse: boolean
}

export function resolveAreaProgressGroupIndex(state: AreaProgressState, groupCount: number) {
  if (!Number.isInteger(groupCount) || groupCount < 1) {
    return null
  }

  if (state.allDone) {
    return groupCount
  }

  if (!Number.isInteger(state.currentAreaIndex) || state.currentAreaIndex === null) {
    return null
  }

  if (state.currentAreaIndex < 1 || state.currentAreaIndex > groupCount) {
    return null
  }

  return state.currentAreaIndex
}

export function createDefaultAreaProgressState(): AreaProgressState {
  return {
    currentAreaIndex: null,
    totalAreaCount: null,
    justFinishedAreaIndex: null,
    readyForNextArea: false,
    allDone: false
  }
}

function normalizeJustFinishedAreaIndex(index: number) {
  return index > 0 ? index : null
}

export function deriveAreaProgressUpdate(
  previousState: AreaProgressState,
  message: RosAreaProgressMessage
): AreaProgressUpdate {
  const justFinishedAreaIndex = normalizeJustFinishedAreaIndex(message.just_finished_area_index)
  return {
    state: {
      currentAreaIndex: message.current_area_index,
      totalAreaCount: message.total_area_count,
      justFinishedAreaIndex,
      readyForNextArea: message.ready_for_next_area,
      allDone: message.all_done
    },
    shouldPulse:
      justFinishedAreaIndex !== null &&
      justFinishedAreaIndex !== previousState.justFinishedAreaIndex
  }
}

export function useAreaProgress(topicName = ROS_AREA_PROGRESS_TOPIC) {
  const { status: rosStatus } = useRosBridgeConnection()
  const state = ref<AreaProgressState>(createDefaultAreaProgressState())
  const hasReceivedMessage = ref(false)
  const justFinishedPulse = ref(false)

  let subscriptionVersion = 0
  let releaseSubscription: null | (() => void) = null
  let pulseTimer: ReturnType<typeof setTimeout> | null = null

  function stopSubscription() {
    if (!releaseSubscription) {
      return
    }

    releaseSubscription()
    releaseSubscription = null
  }

  function clearPulseTimer() {
    if (pulseTimer === null) {
      return
    }

    clearTimeout(pulseTimer)
    pulseTimer = null
  }

  function resetState() {
    state.value = createDefaultAreaProgressState()
    hasReceivedMessage.value = false
    justFinishedPulse.value = false
    clearPulseTimer()
  }

  function triggerPulse() {
    clearPulseTimer()
    justFinishedPulse.value = true

    pulseTimer = setTimeout(() => {
      justFinishedPulse.value = false
      pulseTimer = null
    }, JUST_FINISHED_PULSE_DURATION_MS)
  }

  async function bindSubscription() {
    subscriptionVersion += 1
    const activeVersion = subscriptionVersion

    stopSubscription()

    if (rosStatus.value !== 'connected') {
      resetState()
      return
    }

    try {
      const unsubscribe = await subscribeToRosTopic<RosAreaProgressMessage>({
        topicName,
        messageType: ROS_AREA_PROGRESS_MESSAGE_TYPE,
        onMessage: (message) => {
          if (activeVersion !== subscriptionVersion) {
            return
          }

          const normalized = normalizeAreaProgress(message)
          if (!normalized) {
            return
          }

          const update = deriveAreaProgressUpdate(state.value, normalized)
          hasReceivedMessage.value = true
          state.value = update.state

          if (update.shouldPulse) {
            triggerPulse()
          }
        }
      })

      if (activeVersion !== subscriptionVersion) {
        unsubscribe()
        return
      }

      releaseSubscription = unsubscribe
    } catch {
      resetState()
    }
  }

  watch(rosStatus, () => {
    void bindSubscription()
  }, { immediate: true })

  onScopeDispose(() => {
    subscriptionVersion += 1
    stopSubscription()
    clearPulseTimer()
  })

  return {
    state,
    hasReceivedMessage,
    justFinishedPulse
  }
}
