export interface Scene {
  id: number
  name: string
  createdAt: string
}

export interface ScenePointRecord {
  pointId: number
  sceneId: number
  isFailed: boolean
  note: string
  updatedAt: string
}

export interface WorkbenchContextPayload {
  sceneId: number | null
  selectedPointId: number | null
}

export interface GroupNoteOverride {
  pointId: number
  note: string
}

export interface ManualGroupSavePayload {
  sceneId: number
  selectedPointId: number
  noteOverrides?: GroupNoteOverride[]
}

export interface AutoDetectedPointPayload {
  idx: number
  pixCoord: [number, number]
  worldCoord: [number, number, number]
  angle: number
  isShuiguan: boolean
}

export interface AcceptancePlanPoint {
  pointId: number
  areaIndex: number
  localIndex: number
  x: number
  y: number
  worldCoord: [number, number, number]
  angle: number
  checkerboardParity: number
  isCheckerboardMember: boolean
}

export interface AcceptancePlanArea {
  areaIndex: number
  pointIds: number[]
}

export interface AcceptancePlanPayload {
  points: AcceptancePlanPoint[]
  areas: AcceptancePlanArea[]
  pointCount: number
  maxPointId: number
  rowCount: number
  columnCount: number
  receivedAt: string
}

export interface AcceptancePlanResponse {
  plan: AcceptancePlanPayload | null
}

export interface AutoGroupSavePayload {
  sceneId?: number
  selectedPointId?: number
  groupIndex?: number
  sourceTopic?: string
  rawSignal?: string
  capturedAt?: string
  mimeType?: string
  rgbBase64?: string
  detectedPoints: AutoDetectedPointPayload[]
}

export interface GroupSaveSummary {
  id: number
  sceneId: number
  selectedPointId: number
  groupIndex: number
  source: 'manual' | 'ros'
  rgbPath: string
  createdAt: string
}

export interface ManualGroupSaveResponse {
  form: FormDataPayload
  saveRecord: GroupSaveSummary
}

export interface AutoGroupSaveResponse {
  saveRecord: GroupSaveSummary
}

export interface ScenePointState {
  isFailed: boolean
  hasRecord: boolean
  note: string
  updatedAt: string
}

export type ExportScope = 'scene' | 'all'

export interface GridDimensionsInput {
  rowCount: number
  columnCount: number
}

export interface MatrixMeta {
  pointCount: number
  columnCount: number
  rowCount: number
  groupSize: number
}

export interface FormSettings extends MatrixMeta {}

export interface SceneStat {
  sceneId: number
  sceneName: string
  recordedCount: number
  recordedSuccessCount: number
  defaultSuccessCount: number
  failureCount: number
  successCount: number
  notedCount: number
}

export interface FormStats {
  totalPoints: number
  totalScenes: number
  sceneStats: SceneStat[]
}

export interface FormDataPayload {
  settings: FormSettings
  scenes: Scene[]
  records: ScenePointRecord[]
  stats: FormStats
  matrixMeta?: MatrixMeta
}
