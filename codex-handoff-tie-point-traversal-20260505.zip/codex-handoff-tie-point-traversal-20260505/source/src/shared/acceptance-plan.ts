import type { AcceptancePlanArea, AcceptancePlanPayload, AcceptancePlanPoint } from './types.js'

type RawPlanPayload = {
  areas?: unknown
}

type RawPlanArea = {
  area_index?: unknown
  groups?: unknown
}

type RawPlanGroup = {
  points?: unknown
}

type RawPlanPoint = {
  global_idx?: unknown
  global_row?: unknown
  global_col?: unknown
  local_idx?: unknown
  x?: unknown
  y?: unknown
  z?: unknown
  angle?: unknown
  checkerboard_parity?: unknown
  is_checkerboard_member?: unknown
}

function toPositiveInteger(value: unknown) {
  const numeric = typeof value === 'number' ? value : Number(value)
  return Number.isInteger(numeric) && numeric > 0 ? numeric : null
}

function toNonNegativeInteger(value: unknown) {
  const numeric = typeof value === 'number' ? value : Number(value)
  return Number.isInteger(numeric) && numeric >= 0 ? numeric : null
}

function toFiniteNumber(value: unknown, fallback = 0) {
  const numeric = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(numeric) ? numeric : fallback
}

function toBoolean(value: unknown) {
  if (typeof value === 'boolean') {
    return value
  }

  if (value === 1 || value === '1' || value === 'true') {
    return true
  }

  if (value === 0 || value === '0' || value === 'false') {
    return false
  }

  return false
}

function normalizePlanPoint(areaIndex: number, payload: unknown): AcceptancePlanPoint | null {
  if (!payload || typeof payload !== 'object') {
    return null
  }

  const point = payload as RawPlanPoint
  const pointId = toPositiveInteger(point.global_idx)
  const x = toNonNegativeInteger(point.global_col)
  const y = toNonNegativeInteger(point.global_row)
  const localIndex = toPositiveInteger(point.local_idx)

  if (pointId === null || x === null || y === null || localIndex === null) {
    return null
  }

  return {
    pointId,
    areaIndex,
    localIndex,
    x,
    y,
    worldCoord: [
      toFiniteNumber(point.x),
      toFiniteNumber(point.y),
      toFiniteNumber(point.z)
    ],
    angle: toFiniteNumber(point.angle),
    checkerboardParity: toFiniteNumber(point.checkerboard_parity),
    isCheckerboardMember: toBoolean(point.is_checkerboard_member)
  }
}

export function parseAcceptancePlanJson(
  payload: string,
  receivedAt = new Date().toISOString()
): AcceptancePlanPayload | null {
  const normalizedPayload = payload.trim()
  if (!normalizedPayload) {
    return null
  }

  let parsed: RawPlanPayload
  try {
    parsed = JSON.parse(normalizedPayload) as RawPlanPayload
  } catch {
    return null
  }

  if (!Array.isArray(parsed.areas)) {
    return null
  }

  const pointMap = new Map<number, AcceptancePlanPoint>()
  const areas: AcceptancePlanArea[] = []
  let maxX = -1
  let maxY = -1
  let maxPointId = 0

  for (const rawArea of parsed.areas) {
    if (!rawArea || typeof rawArea !== 'object') {
      continue
    }

    const area = rawArea as RawPlanArea
    const areaIndex = toPositiveInteger(area.area_index)
    if (areaIndex === null || !Array.isArray(area.groups)) {
      continue
    }

    const areaPointIds: number[] = []
    for (const rawGroup of area.groups) {
      if (!rawGroup || typeof rawGroup !== 'object') {
        continue
      }

      const group = rawGroup as RawPlanGroup
      if (!Array.isArray(group.points)) {
        continue
      }

      for (const rawPoint of group.points) {
        const point = normalizePlanPoint(areaIndex, rawPoint)
        if (!point) {
          continue
        }

        areaPointIds.push(point.pointId)
        maxX = Math.max(maxX, point.x)
        maxY = Math.max(maxY, point.y)
        maxPointId = Math.max(maxPointId, point.pointId)

        if (!pointMap.has(point.pointId)) {
          pointMap.set(point.pointId, point)
        }
      }
    }

    const uniquePointIds = Array.from(new Set(areaPointIds))
    if (uniquePointIds.length === 0) {
      continue
    }

    areas.push({
      areaIndex,
      pointIds: uniquePointIds
    })
  }

  const points = [...pointMap.values()].sort((left, right) => left.pointId - right.pointId)
  if (points.length === 0 || areas.length === 0 || maxX < 0 || maxY < 0) {
    return null
  }

  areas.sort((left, right) => left.areaIndex - right.areaIndex)

  return {
    points,
    areas,
    pointCount: points.length,
    maxPointId,
    rowCount: maxY + 1,
    columnCount: maxX + 1,
    receivedAt
  }
}
