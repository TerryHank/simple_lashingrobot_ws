function assertPositiveInteger(value: number, name: string) {
  if (!Number.isInteger(value) || value < 1) {
    throw new RangeError(`${name} must be a positive integer`)
  }
}

type Coordinate = {
  x: number
  y: number
}

export type MatrixRotation = 0 | 90 | 180 | 270

type TraversalData = {
  coordinatesById: Coordinate[]
  pointIdByCoordinate: Map<string, number>
  groups: number[][]
  groupIndexByBand: Map<string, number>
  groupNavigationPointIds: number[]
}

const traversalCache = new Map<string, TraversalData>()

function createCoordinateKey(x: number, y: number) {
  return `${x}:${y}`
}

function createBandKey(xBand: number, yBand: number) {
  return `${xBand}:${yBand}`
}

function assertNonNegativeInteger(value: number, name: string) {
  if (!Number.isInteger(value) || value < 0) {
    throw new RangeError(`${name} must be a non-negative integer`)
  }
}

function getBandStart(nominalStart: number, limit: number) {
  if (limit <= 2) {
    return 0
  }

  return Math.max(0, Math.min(limit - 2, nominalStart))
}

function buildTraversalData(pointCount: number, columnCount: number): TraversalData {
  assertPositiveInteger(pointCount, 'pointCount')
  assertPositiveInteger(columnCount, 'columnCount')

  const rowCount = Math.ceil(pointCount / columnCount)
  const xBandCount = Math.ceil(columnCount / 2)
  const yBandCount = Math.ceil(rowCount / 2)
  const coordinatesById: Coordinate[] = []
  const pointIdByCoordinate = new Map<string, number>()
  const groups: number[][] = []
  const groupIndexByBand = new Map<string, number>()
  const groupNavigationPointIds: number[] = []

  for (let xBand = 0; xBand < xBandCount && coordinatesById.length < pointCount; xBand += 1) {
    const movingUp = xBand % 2 === 0
    const yBands = movingUp
      ? Array.from({ length: yBandCount }, (_, index) => index)
      : Array.from({ length: yBandCount }, (_, index) => yBandCount - 1 - index)
    const localOffsets = movingUp
      ? [
          { dx: 0, dy: 0 },
          { dx: 1, dy: 0 },
          { dx: 0, dy: 1 },
          { dx: 1, dy: 1 }
        ]
      : [
          { dx: 0, dy: 1 },
          { dx: 1, dy: 1 },
          { dx: 0, dy: 0 },
          { dx: 1, dy: 0 }
        ]

    for (const yBand of yBands) {
      if (coordinatesById.length >= pointCount) {
        break
      }
      const xStart = xBand * 2
      const yStart = yBand * 2

      for (const offset of localOffsets) {
        if (coordinatesById.length >= pointCount) {
          break
        }

        const x = xStart + offset.dx
        const y = yStart + offset.dy

        if (x >= columnCount || y >= rowCount) {
          continue
        }

        const pointId = coordinatesById.length + 1
        coordinatesById.push({ x, y })
        pointIdByCoordinate.set(createCoordinateKey(x, y), pointId)
      }
    }
  }

  if (coordinatesById.length !== pointCount) {
    throw new RangeError('matrix traversal failed to cover all points')
  }

  for (let xBand = 0; xBand < xBandCount; xBand += 1) {
    const movingUp = xBand % 2 === 0
    const yBands = movingUp
      ? Array.from({ length: yBandCount }, (_, index) => index)
      : Array.from({ length: yBandCount }, (_, index) => yBandCount - 1 - index)
    const localOffsets = movingUp
      ? [
          { dx: 0, dy: 0 },
          { dx: 1, dy: 0 },
          { dx: 0, dy: 1 },
          { dx: 1, dy: 1 }
        ]
      : [
          { dx: 0, dy: 1 },
          { dx: 1, dy: 1 },
          { dx: 0, dy: 0 },
          { dx: 1, dy: 0 }
        ]

    for (const yBand of yBands) {
      const xStart = getBandStart(xBand * 2, columnCount)
      const yStart = getBandStart(yBand * 2, rowCount)
      const group: number[] = []

      for (const offset of localOffsets) {
        const pointId =
          pointIdByCoordinate.get(createCoordinateKey(xStart + offset.dx, yStart + offset.dy)) ?? null

        if (pointId !== null) {
          group.push(pointId)
        }
      }

      if (group.length === 0) {
        continue
      }

      groups.push(group)
      const groupIndex = groups.length
      groupIndexByBand.set(createBandKey(xBand, yBand), groupIndex)
      const navigationPointId =
        group.find((pointId) => {
          const coordinate = coordinatesById[pointId - 1]
          return (
            Math.floor(coordinate.x / 2) === xBand &&
            Math.floor(coordinate.y / 2) === yBand
          )
        }) ?? group[0]
      groupNavigationPointIds[groupIndex - 1] = navigationPointId
    }
  }

  return {
    coordinatesById,
    pointIdByCoordinate,
    groups,
    groupIndexByBand,
    groupNavigationPointIds
  }
}

function getTraversalData(pointCount: number, columnCount: number) {
  const cacheKey = `${pointCount}:${columnCount}`
  const cached = traversalCache.get(cacheKey)
  if (cached) {
    return cached
  }

  const traversal = buildTraversalData(pointCount, columnCount)
  traversalCache.set(cacheKey, traversal)
  return traversal
}

export function getMatrixDimensions(pointCount: number) {
  assertPositiveInteger(pointCount, 'pointCount')

  const columnCount = Math.ceil(Math.sqrt(pointCount))
  const rowCount = Math.ceil(pointCount / columnCount)

  return { columnCount, rowCount }
}

export function getExactGridDimensions(pointCount: number) {
  assertPositiveInteger(pointCount, 'pointCount')

  for (let rowCount = Math.floor(Math.sqrt(pointCount)); rowCount >= 1; rowCount -= 1) {
    if (pointCount % rowCount === 0) {
      return {
        rowCount,
        columnCount: pointCount / rowCount
      }
    }
  }

  return {
    rowCount: 1,
    columnCount: pointCount
  }
}

export function getPointCountFromGrid(rowCount: number, columnCount: number) {
  assertPositiveInteger(rowCount, 'rowCount')
  assertPositiveInteger(columnCount, 'columnCount')

  return rowCount * columnCount
}

export function normalizeMatrixRotation(rotation: number): MatrixRotation {
  const normalized = ((rotation % 360) + 360) % 360
  if (normalized === 90 || normalized === 180 || normalized === 270) {
    return normalized
  }

  return 0
}

export function getRotatedMatrixDimensions(
  rowCount: number,
  columnCount: number,
  rotation: number
) {
  assertPositiveInteger(rowCount, 'rowCount')
  assertPositiveInteger(columnCount, 'columnCount')

  const normalized = normalizeMatrixRotation(rotation)
  if (normalized === 90 || normalized === 270) {
    return {
      rowCount: columnCount,
      columnCount: rowCount
    }
  }

  return {
    rowCount,
    columnCount
  }
}

export function getRotatedDisplayCoordinate(
  coordinate: Coordinate,
  rowCount: number,
  columnCount: number,
  rotation: number
) {
  assertPositiveInteger(rowCount, 'rowCount')
  assertPositiveInteger(columnCount, 'columnCount')
  assertNonNegativeInteger(coordinate.x, 'coordinate.x')
  assertNonNegativeInteger(coordinate.y, 'coordinate.y')

  const normalized = normalizeMatrixRotation(rotation)

  switch (normalized) {
    case 90:
      return {
        x: rowCount - 1 - coordinate.y,
        y: columnCount - 1 - coordinate.x
      }
    case 180:
      return {
        x: columnCount - 1 - coordinate.x,
        y: coordinate.y
      }
    case 270:
      return {
        x: coordinate.y,
        y: coordinate.x
      }
    default:
      return {
        x: coordinate.x,
        y: rowCount - 1 - coordinate.y
      }
  }
}

export function getLogicalCoordinateFromDisplay(
  displayX: number,
  displayY: number,
  rowCount: number,
  columnCount: number,
  rotation: number
) {
  assertPositiveInteger(rowCount, 'rowCount')
  assertPositiveInteger(columnCount, 'columnCount')
  assertNonNegativeInteger(displayX, 'displayX')
  assertNonNegativeInteger(displayY, 'displayY')

  const normalized = normalizeMatrixRotation(rotation)

  switch (normalized) {
    case 90:
      return {
        x: columnCount - 1 - displayY,
        y: rowCount - 1 - displayX
      }
    case 180:
      return {
        x: columnCount - 1 - displayX,
        y: displayY
      }
    case 270:
      return {
        x: displayY,
        y: displayX
      }
    default:
      return {
        x: displayX,
        y: rowCount - 1 - displayY
      }
  }
}

export function getPointCoordinate(pointId: number, pointCount: number, columnCount: number) {
  assertPositiveInteger(pointId, 'pointId')
  assertPositiveInteger(pointCount, 'pointCount')
  assertPositiveInteger(columnCount, 'columnCount')

  if (pointId > pointCount) {
    throw new RangeError('pointId must not exceed pointCount')
  }

  const coordinate = getTraversalData(pointCount, columnCount).coordinatesById[pointId - 1]

  if (!coordinate) {
    throw new RangeError('pointId must map to a coordinate')
  }

  return coordinate
}

export function getPointIdAtCoordinate(
  x: number,
  y: number,
  pointCount: number,
  columnCount: number
) {
  assertPositiveInteger(pointCount, 'pointCount')
  assertPositiveInteger(columnCount, 'columnCount')

  if (!Number.isInteger(x) || !Number.isInteger(y)) {
    return null
  }

  const rowCount = Math.ceil(pointCount / columnCount)

  if (x < 0 || y < 0 || x >= columnCount || y >= rowCount) {
    return null
  }

  return getTraversalData(pointCount, columnCount).pointIdByCoordinate.get(createCoordinateKey(x, y)) ?? null
}

function buildMatrixGroups(pointCount: number, columnCount: number) {
  return getTraversalData(pointCount, columnCount).groups.map((group) => [...group])
}

export function getGroupCount(pointCount: number, columnCount: number) {
  return Math.max(1, buildMatrixGroups(pointCount, columnCount).length)
}

export function getGroupIndex(pointId: number, pointCount: number, columnCount: number) {
  assertPositiveInteger(pointId, 'pointId')
  assertPositiveInteger(pointCount, 'pointCount')
  assertPositiveInteger(columnCount, 'columnCount')

  if (pointId > pointCount) {
    throw new RangeError('pointId must not exceed pointCount')
  }

  const coordinate = getTraversalData(pointCount, columnCount).coordinatesById[pointId - 1]
  const xBand = Math.min(
    Math.floor(coordinate.x / 2),
    Math.ceil(columnCount / 2) - 1
  )
  const yBand = Math.min(
    Math.floor(coordinate.y / 2),
    Math.ceil(Math.ceil(pointCount / columnCount) / 2) - 1
  )
  const groupIndex =
    getTraversalData(pointCount, columnCount).groupIndexByBand.get(createBandKey(xBand, yBand)) ?? -1

  if (groupIndex === -1) {
    throw new RangeError('pointId must map to a matrix group')
  }

  return groupIndex
}

export function getGroupPointIdsForPoint(
  pointId: number,
  pointCount: number,
  columnCount: number
) {
  assertPositiveInteger(pointId, 'pointId')
  assertPositiveInteger(pointCount, 'pointCount')
  assertPositiveInteger(columnCount, 'columnCount')
  if (pointId > pointCount) {
    throw new RangeError('pointId must not exceed pointCount')
  }

  const groupIndex = getGroupIndex(pointId, pointCount, columnCount)
  const group = buildMatrixGroups(pointCount, columnCount)[groupIndex - 1]

  if (!group) {
    throw new RangeError('pointId must map to a matrix group')
  }

  return [...group]
}

export function getGroupPointIds(
  groupIndex: number,
  pointCount: number,
  columnCount: number
) {
  assertPositiveInteger(groupIndex, 'groupIndex')
  assertPositiveInteger(pointCount, 'pointCount')
  assertPositiveInteger(columnCount, 'columnCount')

  const groups = buildMatrixGroups(pointCount, columnCount)
  const group = groups[groupIndex - 1]

  if (!group) {
    throw new RangeError('groupIndex must not exceed group count')
  }

  return [...group]
}

export function getGroupNavigationPointId(
  groupIndex: number,
  pointCount: number,
  columnCount: number
) {
  assertPositiveInteger(groupIndex, 'groupIndex')
  assertPositiveInteger(pointCount, 'pointCount')
  assertPositiveInteger(columnCount, 'columnCount')

  const navigationPointId =
    getTraversalData(pointCount, columnCount).groupNavigationPointIds[groupIndex - 1]

  if (!navigationPointId) {
    throw new RangeError('groupIndex must not exceed group count')
  }

  return navigationPointId
}

export function formatAxisValue(value: number) {
  assertNonNegativeInteger(value, 'value')
  return (value + 1).toString().padStart(2, '0')
}
