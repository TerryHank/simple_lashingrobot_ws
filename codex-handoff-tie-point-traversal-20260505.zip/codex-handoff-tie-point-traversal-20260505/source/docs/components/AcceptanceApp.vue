<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useData } from 'vitepress'
import PointGrid from './PointGrid.vue'
import PointInspector from './PointInspector.vue'
import ProgressHeader from './ProgressHeader.vue'
import RosBridgeControl from './RosBridgeControl.vue'
import { fetchAcceptancePlan } from '../../src/client/api.js'
import { useAreaProgress } from '../../src/client/area-progress.js'
import { useAcceptancePlan } from '../../src/client/acceptance-plan.js'
import { useRosGroupEvidence } from '../../src/client/ros-evidence.js'
import { createAcceptanceStore } from '../../src/client/store.js'

const store = createAcceptanceStore()
const areaProgress = useAreaProgress()
const acceptancePlan = useAcceptancePlan()
const rosGroupEvidence = useRosGroupEvidence()
const { isDark } = useData()
const exportMenuOpen = ref(false)
const exportMenuRef = ref<HTMLElement | null>(null)
const MATRIX_ROTATION_STORAGE_KEY = 'acceptance-form:matrix-rotation'
const matrixRotation = ref(0)
const lastAutoSavedGroupIndex = ref<number | null>(null)

const activeSceneName = computed(() => store.activeScene.value?.name ?? null)
const canExportScene = computed(() => store.activeSceneId.value !== null)
const canExportAll = computed(() => store.scenes.value.length > 0)
const matrixRotationLabel = computed(() => `视角 ${matrixRotation.value}°`)
const visibleAreaProgress = computed(() =>
  areaProgress.hasReceivedMessage.value ? areaProgress.state.value : null
)
const syncedAreaGroupIndex = computed(() => {
  if (!areaProgress.hasReceivedMessage.value) {
    return null
  }

  return store.resolveExternalGroupIndex(
    areaProgress.state.value.currentAreaIndex,
    areaProgress.state.value.allDone
  )
})
const isAreaProgressControlled = computed(() => syncedAreaGroupIndex.value !== null)
const currentGroupPointIds = computed(() => store.currentGroupPoints.value.map((point) => point.pointId))
const justFinishedPointIds = computed(() => {
  const progress = visibleAreaProgress.value
  if (!progress || progress.justFinishedAreaIndex === null) {
    return []
  }

  return store.getPointIdsForGroup(progress.justFinishedAreaIndex)
})

watch(
  () => acceptancePlan.state.value,
  (plan) => {
    if (!plan) {
      return
    }

    void store.applyAcceptancePlan(plan)
  },
  { immediate: true }
)

watch(
  () => [
    syncedAreaGroupIndex.value,
    store.currentGroupIndex.value
  ] as const,
  ([targetGroupIndex, currentGroupIndex]) => {
    if (targetGroupIndex === null || currentGroupIndex === targetGroupIndex) {
      return
    }

    void store.goToGroup(targetGroupIndex)
  },
  { immediate: true }
)

watch(
  () => [
    areaProgress.state.value.readyForNextArea,
    areaProgress.state.value.justFinishedAreaIndex,
    areaProgress.state.value.currentAreaIndex,
    areaProgress.state.value.totalAreaCount,
    areaProgress.state.value.allDone,
    rosGroupEvidence.latest.value.capturedAt,
    rosGroupEvidence.latest.value.rgbBase64,
    rosGroupEvidence.latest.value.detectedPoints.length
  ] as const,
  ([readyForNextArea, justFinishedAreaIndex]) => {
    if (!areaProgress.hasReceivedMessage.value || !readyForNextArea || justFinishedAreaIndex === null) {
      return
    }

    if (lastAutoSavedGroupIndex.value === justFinishedAreaIndex) {
      return
    }

    lastAutoSavedGroupIndex.value = justFinishedAreaIndex
    void store.saveGroupFromRos({
      groupIndex: justFinishedAreaIndex,
      sourceTopic: rosGroupEvidence.latest.value.sourceTopic,
      rawSignal: JSON.stringify(areaProgress.state.value),
      capturedAt: rosGroupEvidence.latest.value.capturedAt || new Date().toISOString(),
      mimeType: rosGroupEvidence.latest.value.mimeType,
      rgbBase64: rosGroupEvidence.latest.value.rgbBase64,
      detectedPoints: rosGroupEvidence.latest.value.detectedPoints
    })
  }
)

onMounted(() => {
  if (typeof window !== 'undefined') {
    const storedRotation = Number(window.localStorage.getItem(MATRIX_ROTATION_STORAGE_KEY) ?? 0)
    matrixRotation.value = [0, 90, 180, 270].includes(storedRotation) ? storedRotation : 0
  }
  void bootstrapWorkbench()
  document.addEventListener('pointerdown', handleDocumentPointerDown)
  document.addEventListener('keydown', handleDocumentKeydown)
})

onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', handleDocumentPointerDown)
  document.removeEventListener('keydown', handleDocumentKeydown)
})

function toggleTheme() {
  isDark.value = !isDark.value
}

function toggleExportMenu() {
  exportMenuOpen.value = !exportMenuOpen.value
}

function handleExport(scope: 'scene' | 'all') {
  exportMenuOpen.value = false
  store.exportExcel(scope)
}

function cycleMatrixRotation() {
  matrixRotation.value = (matrixRotation.value + 90) % 360
  if (typeof window !== 'undefined') {
    window.localStorage.setItem(MATRIX_ROTATION_STORAGE_KEY, String(matrixRotation.value))
  }
}

function handleDocumentPointerDown(event: PointerEvent) {
  if (!exportMenuOpen.value || !exportMenuRef.value) {
    return
  }

  const target = event.target
  if (!(target instanceof Node)) {
    return
  }

  if (!exportMenuRef.value.contains(target)) {
    exportMenuOpen.value = false
  }
}

function handleDocumentKeydown(event: KeyboardEvent) {
  if (event.key === 'Escape') {
    exportMenuOpen.value = false
  }
}

async function bootstrapWorkbench() {
  await store.load()

  try {
    const response = await fetchAcceptancePlan()
    if (response.plan) {
      await store.applyAcceptancePlan(response.plan)
    }
  } catch {
    // Keep the local matrix fallback when the plan file is unavailable.
  }
}

async function handleSelectPoint(pointId: number) {
  if (!isAreaProgressControlled.value) {
    await store.goToPoint(pointId)
    return
  }

  const targetGroupIndex = store.getGroupIndexForPoint(pointId)
  if (targetGroupIndex !== syncedAreaGroupIndex.value) {
    return
  }

  await store.goToPoint(pointId)
}

async function handleMoveGroup(offset: number) {
  if (isAreaProgressControlled.value) {
    return
  }

  await store.moveGroup(offset)
}

async function handleAdvanceGroup(noteOverrides: Parameters<typeof store.saveCurrentGroup>[0]) {
  if (isAreaProgressControlled.value) {
    await store.saveCurrentGroup(noteOverrides)
    return
  }

  await store.saveCurrentGroupAndMoveNext(noteOverrides)
}
</script>

<template>
  <div class="acceptance-shell">
    <header class="acceptance-pagebar">
      <div class="acceptance-pagebar__center">
        <RosBridgeControl class="acceptance-pagebar__ros" />
        <button
          class="acceptance-pagebar__rotate"
          type="button"
          :aria-label="`切换点阵视角，当前 ${matrixRotation} 度`"
          @click="cycleMatrixRotation"
        >
          {{ matrixRotationLabel }}
        </button>
      </div>
      <div class="acceptance-pagebar__tools">
        <button
          class="acceptance-theme-toggle"
          type="button"
          :aria-pressed="isDark"
          :aria-label="isDark ? '切换到浅色模式' : '切换到深色模式'"
          @click="toggleTheme"
        >
          <span class="acceptance-theme-toggle__track" :class="{ 'is-dark': isDark }">
            <span class="acceptance-theme-toggle__thumb" />
          </span>
          <span class="acceptance-theme-toggle__label">{{ isDark ? '浅色模式' : '深色模式' }}</span>
        </button>
        <div
          ref="exportMenuRef"
          class="acceptance-export acceptance-pagebar__export acceptance-menu"
          :class="{ 'is-open': exportMenuOpen }"
        >
          <button
            class="acceptance-pagebar__icon-button"
            type="button"
            aria-label="下载实验报表"
            aria-haspopup="menu"
            :aria-expanded="exportMenuOpen"
            @click="toggleExportMenu"
          >
            <svg class="acceptance-pagebar__icon" viewBox="0 0 24 24" aria-hidden="true">
              <path
                d="M12 3.75a.75.75 0 0 1 .75.75v8.69l2.72-2.72a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 0 1 1.06-1.06l2.72 2.72V4.5a.75.75 0 0 1 .75-.75ZM5.5 18.25a.75.75 0 0 1 .75.75v.25h11.5V19a.75.75 0 0 1 1.5 0v1a.75.75 0 0 1-.75.75H5.5a.75.75 0 0 1-.75-.75v-1a.75.75 0 0 1 .75-.75Z"
                fill="currentColor"
              />
            </svg>
          </button>

          <div v-if="exportMenuOpen" class="acceptance-menu__dropdown acceptance-menu__dropdown--export" role="menu">
            <button
              class="acceptance-menu__item"
              type="button"
              role="menuitem"
              :disabled="!canExportScene"
              @click="handleExport('scene')"
            >
              下载当前场景实验报表
            </button>
            <button
              class="acceptance-menu__item"
              type="button"
              role="menuitem"
              :disabled="!canExportAll"
              @click="handleExport('all')"
            >
              下载全部场景实验报表
            </button>
          </div>
        </div>
      </div>
    </header>

    <div v-if="store.errorMessage.value" class="acceptance-banner is-error">
      {{ store.errorMessage.value }}
    </div>

    <div v-if="store.loading.value && !store.initialized.value" class="acceptance-empty-panel">
      正在加载矩阵验收工作台…
    </div>

    <template v-else-if="store.scenes.value.length === 0">
      <div class="acceptance-empty-panel">
        <h2>先新增一个场景</h2>
          <p>场景建立后，左侧会出现四宫格工作台，右侧会按当前行列生成直角坐标点阵。</p>
      </div>

      <ProgressHeader
        variant="full"
        :settings="store.settings.value"
        :scenes="store.scenes.value"
        :active-scene-id="store.activeSceneId.value"
        :active-scene-stats="store.activeSceneStats.value"
        :selected-point-id="store.selectedPointId.value"
        :current-group-index="store.currentGroupIndex.value"
        :group-count="store.groupCount.value"
        :save-state="store.saveState.value"
        :can-export="store.canExport.value"
        @scene-select="store.selectScene"
        @scene-create="store.createScene"
        @scene-delete="store.deleteScene"
        @scene-reset="store.resetScene"
        @grid-change="store.updateGridDimensions"
        @export="store.exportExcel"
      />
    </template>

    <template v-else>
      <div class="acceptance-workbench">
        <div class="acceptance-workbench__aside">
          <PointInspector
            :active-scene-name="activeSceneName"
            :settings="store.settings.value"
            :scenes="store.scenes.value"
            :active-scene-id="store.activeSceneId.value"
            :active-scene-stats="store.activeSceneStats.value"
            :can-export="store.canExport.value"
            :group-points="store.currentGroupPoints.value"
            :selected-point-id="store.selectedPointId.value"
            :current-group-index="store.currentGroupIndex.value"
            :group-count="store.groupCount.value"
            :group-locked="isAreaProgressControlled"
            :save-state="store.saveState.value"
            @select="handleSelectPoint"
            @move-group="handleMoveGroup"
            @advance-group="handleAdvanceGroup"
            @toggle-failed="store.togglePointFailed"
            @note-change="store.savePointNote"
            @scene-select="store.selectScene"
            @scene-create="store.createScene"
            @scene-delete="store.deleteScene"
            @scene-reset="store.resetScene"
            @grid-change="store.updateGridDimensions"
          />
        </div>

        <PointGrid
          :active-scene-name="activeSceneName"
          :active-scene-stats="store.activeSceneStats.value"
          :matrix-meta="store.matrixMeta.value"
          :matrix-rotation="matrixRotation"
          :area-progress="visibleAreaProgress"
          :just-finished-pulse="areaProgress.justFinishedPulse.value"
          :points="store.gridPoints.value"
          :hovered-point="store.hoveredPoint.value"
          :selected-point-id="store.selectedPointId.value"
          :current-group-point-ids="currentGroupPointIds"
          :just-finished-point-ids="justFinishedPointIds"
          :current-group-index="store.currentGroupIndex.value"
          :group-count="store.groupCount.value"
          @select="handleSelectPoint"
          @hover="store.setHoveredPoint"
        />
      </div>
    </template>

  </div>
</template>

