# 交接包清单

生成时间：2026-05-05

## 文档

- `NEXT_CODEX_START_HERE.md`：下一个 Codex 的阅读入口。
- `HANDOFF.md`：绑扎点遍历方法主说明。
- `SOURCE_MAP.md`：源码证据路径和阅读重点。
- `MANIFEST.md`：本清单。

## 源码快照

源码快照位于 `source/`，只包含理解遍历方法需要的关键文件，不包含 `node_modules`、构建产物、数据库、截图、压缩包。

包含文件：

- `package.json`
- `src/shared/matrix.ts`
- `src/shared/acceptance-plan.ts`
- `src/shared/types.ts`
- `src/client/store.ts`
- `src/client/acceptance-plan.ts`
- `src/client/area-progress.ts`
- `docs/components/AcceptanceApp.vue`
- `src/server/http.ts`
- `src/server/repository.ts`
- `src/server/index.ts`
- `scripts/ros/acceptance_plan_publisher.py`
- `tests/shared/matrix.test.ts`
- `tests/shared/acceptance-plan.test.ts`
- `tests/client/store.test.ts`
- `tests/client/area-progress.test.ts`
- `tests/server/http.test.ts`

## 原工程路径

`d:\UserData\TerryHank\Desktop\26.4.3验收表单`

